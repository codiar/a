import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Link } from "react-router-dom";
import { Button } from "../components/ui/Button";

function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-[#020305] pt-32 pb-36 border-b border-white/5">
      <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-[120px] sm:-top-80 pointer-events-none" aria-hidden="true">
        <div className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#C1A87D] to-[#4A3B2C] opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"></div>
      </div>
      
      {/* Animated Light Beams */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
        className="absolute inset-0 z-0 pointer-events-none overflow-hidden"
      >
         <div className="absolute top-0 left-1/4 w-[1px] h-full bg-gradient-to-b from-white/0 via-white/10 to-white/0" />
         <div className="absolute top-0 right-1/4 w-[1px] h-full bg-gradient-to-b from-white/0 via-white/10 to-white/0" />
      </motion.div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <motion.div
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.15 } }
          }}
        >
          <motion.div variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}>
            <span className="inline-flex items-center gap-2 py-2 px-5 rounded-full bg-white/5 border border-white/10 text-[#C1A87D] text-xs font-bold tracking-widest mb-8 shadow-2xl backdrop-blur-md uppercase">
               <span className="w-2 h-2 rounded-full bg-[#C1A87D] animate-pulse"></span>
               حلول برمجية متكاملة للشركات
            </span>
          </motion.div>
          
          <motion.h1 
            variants={{ hidden: { opacity: 0, y: 30 }, visible: { opacity: 1, y: 0 } }}
            className="text-5xl md:text-7xl lg:text-[5.5rem] font-bold text-white tracking-tight mb-8 leading-[1.1]"
          >
            نصنع تجارب رقمية <br />
            <span className="bg-gradient-to-r from-[#F3E6D5] via-[#C1A87D] to-[#8B8476] text-transparent bg-clip-text font-black">تليق بعلامتك التجارية</span>
          </motion.h1>
          
          <motion.p 
            variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}
            className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto mb-12 font-medium leading-relaxed"
          >
            من المنيو الإلكتروني إلى المنصات المخصصة، Codiar Tech تقدم لعملك في العراق 
            حلولاً برمجية بمستويات عالمية وسرعة فائقة.
          </motion.p>
          
          <motion.div 
            variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}
            className="flex flex-col sm:flex-row items-center justify-center gap-5"
          >
            <Link to="/order" className="w-full sm:w-auto">
              <Button size="lg" className="w-full text-lg px-12 h-14 bg-gradient-to-r from-[#1F1C18] to-[#2C2721] border border-[#4A3B2C] text-[#F3E6D5] hover:border-[#C1A87D] hover:shadow-[0_0_30px_rgba(193,168,125,0.15)] transition-all duration-300">
                ابدأ مشروعك الآن
              </Button>
            </Link>
            <Link to="/portfolio" className="w-full sm:w-auto">
              <Button size="lg" variant="outline" className="w-full text-lg px-12 h-14 bg-white/5 border-white/10 text-white hover:bg-white/10 hover:border-white/20 transition-all duration-300 backdrop-blur-sm">
                استكشف أعمالنا
              </Button>
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

const packages = [
  {
    title: "باقة المشاريع المنزلية",
    description: "للمشاريع الصغيرة والمنزلية",
    price: "مجانًا",
    features: [
      "الموقع مجاني 100%",
      "دعم المشاريع العراقية",
      "دعاء للنبي وآله 🌺"
    ],
    highlight: false,
    theme: "brown",
    cta: "اطلب باقة الدعم"
  },
  {
    title: "الباقة الذهبية",
    description: "مثالية للعيادات والمطاعم الناشئة",
    price: "19,000",
    period: "د.ع / شهرياً",
    features: [
      "دومين رسمي ومطابق لعلامتك",
      "استضافة سريعة وآمنة",
      "شهادة أمان SSL",
      "دعم فني مستمر",
      "20 عنصر منيو كحد أقصى"
    ],
    highlight: false,
    theme: "gold",
    cta: "اختر الذهبية"
  },
  {
    title: "الباقة الاحترافية",
    description: "تسريع النمو والتميز الرقمي",
    price: "39,000",
    period: "د.ع / شهرياً",
    features: [
      "جميع ميزات الذهبية",
      "تصميم UI/UX متقدم",
      "تحسين محركات البحث SEO",
      "حماية إضافية من الهجمات"
    ],
    highlight: false,
    theme: "silver",
    cta: "اختر الاحترافية"
  },
  {
    title: "الباقة الفاخرة",
    description: "الأداء الأقصى للعلامات الرائدة",
    price: "79,000",
    period: "د.ع / شهرياً",
    features: [
      "جميع ميزات الاحترافية",
      "تصميم حصري ومخصص كلياً",
      "أداء فائق السرعة",
      "سيرفر خاص لبياناتك",
      "أعلى معايير الحماية المتوفرة"
    ],
    highlight: true,
    theme: "premium",
    cta: "اطلب الفاخرة المتميزة"
  }
];

function PackagesSection() {
  const getThemeClasses = (theme: string) => {
    switch(theme) {
      case "brown": 
        return "bg-gradient-to-b from-[#2A1E18] to-[#140D09] border-[#4A3222] text-[#F3E6D5] shadow-xl shadow-orange-900/10";
      case "gold":
        return "bg-gradient-to-b from-[#1C1A14] to-[#0D0B08] border-[#8C7A3F] text-[#FDF9ED] shadow-xl shadow-yellow-900/10";
      case "silver":
        return "bg-gradient-to-b from-[#171920] to-[#0A0B0E] border-[#5E6A80] text-[#F1F3F8] shadow-xl shadow-slate-900/10";
      case "premium":
      default:
        return "bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] bg-gradient-to-br from-[#0F1C36] via-[#101321] to-[#1D160D] border-x border-[#BD9A5F] border-y-[#BD9A5F] text-[#F4F6FB] shadow-2xl shadow-blue-900/20";
    }
  };

  const getSubtextClasses = (theme: string) => {
    switch(theme) {
      case "brown": return "text-[#C19B86]";
      case "gold": return "text-[#D6CA96]";
      case "silver": return "text-[#A9B4CC]";
      case "premium": default: return "text-[#D3C7A8]";
    }
  };

  const getButtonClasses = (theme: string) => {
    switch(theme) {
      case "brown": 
        return "bg-gradient-to-r from-[#8C4325] to-[#B65E35] text-white hover:from-[#A8512C] hover:to-[#CD6F42] border-none shadow-[0_0_15px_rgba(182,94,53,0.3)]";
      case "gold":
        return "bg-gradient-to-r from-[#9E8640] to-[#C9B267] text-black hover:from-[#B59C51] hover:to-[#DEC87A] border-none font-extrabold shadow-[0_0_15px_rgba(201,178,103,0.3)]";
      case "silver":
        return "bg-gradient-to-r from-[#50607B] to-[#71829F] text-white hover:from-[#5C6E8D] hover:to-[#8195B4] border-none shadow-[0_0_15px_rgba(113,130,159,0.3)]";
      case "premium":
      default:
        return "bg-gradient-to-r from-[#BD9A5F] via-[#E2C389] to-[#BD9A5F] text-black hover:from-[#D1AC6D] hover:to-[#F1D6A0] border-none font-black shadow-[0_0_20px_rgba(189,154,95,0.4)] transition-all duration-500 bg-[length:200%_auto] hover:bg-[position:right_center]";
    }
  };

  const getIconColor = (theme: string) => {
    switch(theme) {
      case "brown": return "text-[#CD6F42]";
      case "gold": return "text-[#C9B267]";
      case "silver": return "text-[#8195B4]";
      case "premium": default: return "text-[#E2C389]";
    }
  };

  return (
    <section className="py-32 bg-[#05070A] border-b border-brand-border isolate relative">
      <div className="absolute inset-x-0 top-0 -z-10 h-full overflow-hidden blur-[100px] opacity-30 pointer-events-none" aria-hidden="true">
        <div className="absolute left-[20%] top-[10%] w-[30rem] h-[30rem] bg-gradient-to-br from-[#BD9A5F]/20 to-transparent rounded-full mix-blend-screen"></div>
      </div>
      <div className="max-w-[85rem] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-24">
          <h2 className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#F4F6FB] via-[#D3C7A8] to-[#BD9A5F] mb-6 tracking-tight">الباقات الاستثمارية المصممة لنمو مشروعك</h2>
          <p className="text-[#8B92A5] max-w-2xl mx-auto text-lg leading-relaxed font-medium">
            باقات حصرية تليق بالعلامات التجارية الطموحة، مصممة بعناية فائقة لتوفير أفضل أداء رقمي ومظهر احترافي فاخر.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
          {packages.map((pkg, idx) => (
             <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.7, ease: [0.25, 0.4, 0.25, 1] }}
              className={`rounded-[2rem] p-8 border hover:-translate-y-3 transition-all duration-500 relative flex flex-col h-full ${getThemeClasses(pkg.theme || "premium")} ${pkg.highlight ? 'lg:-translate-y-8 lg:scale-[1.03] z-10' : 'z-0'}`}
            >
              {pkg.highlight && (
                 <div className="absolute -top-4 w-full left-0 flex justify-center">
                    <span className="bg-gradient-to-r from-[#BD9A5F] to-[#E2C389] text-black text-[10px] uppercase font-black tracking-widest py-1.5 px-6 rounded-full shadow-lg">القيمة الأفضل</span>
                 </div>
              )}
              
              <div className="flex-1">
                <h3 className={`text-2xl font-black mb-3`}>{pkg.title}</h3>
                <p className={`text-xs mb-8 font-medium h-8 ${getSubtextClasses(pkg.theme || "premium")}`}>{pkg.description}</p>
                
                <div className="mb-10 flex items-end">
                  <span className={`text-4xl font-extrabold tracking-tight`}>{pkg.price}</span>
                  {pkg.period && <span className={`text-xs mr-2 mb-1.5 font-bold ${getSubtextClasses(pkg.theme || "premium")} opacity-80`}> {pkg.period}</span>}
                </div>

                <div className="h-[1px] w-full bg-white/10 mb-8 rounded-full"></div>

                <ul className="space-y-4 mb-10">
                  {pkg.features.map((feature, fIdx) => (
                    <li key={fIdx} className="flex items-start text-sm font-semibold">
                      <svg className={`w-5 h-5 ml-3 shrink-0 ${getIconColor(pkg.theme || "premium")}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="opacity-90">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="pt-4 mt-auto">
                <Link to="/order" className="block w-full">
                  <button className={`w-full h-14 rounded-2xl text-sm transition-all ${getButtonClasses(pkg.theme || "premium")}`}>
                    {pkg.cta}
                  </button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function PortfolioSection() {
  const works = [
    { name: "مطعم عشتار", type: "منيو إلكتروني فخم يعكس الهوية الأصيلة", img: "https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80" },
    { name: "عيادة سندباد", type: "منصة حجز مواعيد وإدارة طبية فاخرة", img: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&w=800&q=80" },
    { name: "شركة سحاب للسفر والسياحة", type: "بوابة حجز تذاكر وسياحة عالمية", img: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=800&q=80" },
    { name: "متجر روان للألبسة الرجالية", type: "متجر أزياء فاخر وإدارة مبيعات ذكية", img: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=800&q=80" },
  ];

  return (
    <section className="py-32 bg-[#020305] border-b border-[#1A1F2D] relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10 pointer-events-none"></div>
      <div className="max-w-[85rem] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400 mb-4 tracking-tight">نصنع ما يجذب الأنظار</h2>
            <p className="text-brand-blue font-bold tracking-widest text-sm uppercase">أفضل أعمالنا</p>
          </div>
          <div>
            <Link to="/order">
              <Button className="bg-white text-black hover:bg-slate-200 font-bold px-8 rounded-full h-12 shadow-xl shadow-white/10">ابدأ مشروعك الآن</Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {works.map((item, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.15, duration: 0.6 }}
              className="group cursor-pointer flex flex-col"
            >
              <div className="overflow-hidden rounded-[2rem] mb-6 shadow-2xl border border-white/5 relative aspect-[16/10] bg-[#0A0D14]">
                <img src={item.img} alt={item.name} className="w-full h-full object-cover transition-transform duration-[1.5s] ease-out group-hover:scale-110 opacity-90 group-hover:opacity-100" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#020305] via-transparent to-transparent opacity-80"></div>
                <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between pointer-events-none">
                  <div className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 text-white transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </div>
                </div>
              </div>
              <div className="px-2">
                <h3 className="text-2xl font-bold text-white mb-2 transition-colors">{item.name}</h3>
                <p className="text-slate-400 font-medium text-sm">{item.type}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useEffect, useState } from "react";
import { collection, query, where, getDocs, addDoc } from "firebase/firestore";
import { db } from "../lib/firebase";

function TestimonialsSection() {
  const [reviews, setReviews] = useState<any[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState("");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const fallbackReviews = [
    { clientName: "أحمد العراقي", stars: 5, comment: "كوديار غيّروا واجهة مطعمي بالكامل. المنيو الإلكتروني سريع جداً والتصميم فائق الروعة، أنصح بهم بشدة." },
    { clientName: "د. سارة محمود", stars: 5, comment: "احترافية لا مثيل لها. تم تصميم وبناء منصة إدارة المواعيد بسلاسة وبأحدث التقنيات. فريق داعم ومستجيب." },
    { clientName: "يوسف علي", stars: 5, comment: "تجربة ممتازة من البداية حتى الاستلام. نظام الفواتير والداشبورد المقدم لنا أعطانا تحكماً كاملاً بأعمالنا." }
  ];

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const q = query(collection(db, "reviews"), where("status", "==", "approved"));
        const snap = await getDocs(q);
        if (!snap.empty) {
          setReviews(snap.docs.map(doc => doc.data()));
        } else {
          setReviews(fallbackReviews);
        }
      } catch (err) {
        console.error("Error fetching reviews:", err);
        setReviews(fallbackReviews);
      }
    };
    fetchReviews();
  }, []);

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim()) return;
    try {
      setSubmitting(true);
      await addDoc(collection(db, "reviews"), {
        clientName: name,
        stars: rating,
        comment: comment,
        status: "pending",
        createdAt: Date.now()
      });
      setSubmitted(true);
      setTimeout(() => {
        setModalOpen(false);
        setSubmitted(false);
        setName("");
        setComment("");
        setRating(5);
      }, 3000);
    } catch (err) {
      console.error("Error writing review:", err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section className="py-32 bg-[#FAF9F6] border-b border-[#EAE6DF] relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-[#1F1C18]/5 to-transparent pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-1/3 h-full bg-gradient-to-r from-orange-900/5 to-transparent pointer-events-none"></div>
      
      <div className="max-w-[85rem] mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="flex flex-col md:flex-row justify-between items-center mb-20 gap-8">
          <div className="text-right flex-1 w-full text-center md:text-right">
            <h2 className="text-4xl md:text-5xl font-black text-[#1F1C18] mb-4 tracking-tight flex items-center justify-center md:justify-start gap-4">
              شركاء النجاح
              <span className="bg-[#1F1C18] text-[#D0C0A8] text-[10px] px-3 py-1.5 rounded-full font-bold uppercase tracking-widest translate-y-1 shadow-lg">موثق</span>
            </h2>
            <p className="text-[#645C51] max-w-xl mx-auto md:mx-0 text-lg leading-relaxed font-semibold">
              نفخر بثقة عملائنا في مختلف القطاعات. تقييمات تستند إلى تجارب حقيقية تدعم مسيرتنا في تطوير أفضل الحلول.
            </p>
          </div>
          <div>
            <button 
              onClick={() => setModalOpen(true)}
              className="px-8 py-4 rounded-2xl bg-gradient-to-r from-[#1F1C18] to-[#2C2721] text-[#F3E6D5] border border-[#4A3B2C] font-bold hover:border-[#C1A87D] hover:shadow-[0_0_30px_rgba(193,168,125,0.15)] transition-all outline-none"
            >
              أضف تقييمك الآن
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              className="bg-[#0c101d] rounded-3xl p-8 border border-white/5 shadow-2xl hover:shadow-[0_15px_50px_-15px_rgba(193,168,125,0.15)] hover:-translate-y-1 hover:border-[#C1A87D]/30 transition-all duration-300 relative flex flex-col"
            >
              <div className="flex items-center justify-between mb-6">
                 <div className="flex items-center gap-3">
                   <div className="w-12 h-12 bg-gradient-to-br from-[#1F1C18] to-[#4A3B2C] rounded-full flex items-center justify-center text-[#F3E6D5] font-bold text-lg shadow-inner border border-[#C1A87D]/20">
                     {review.clientName?.charAt(0) || "ع"}
                   </div>
                   <div>
                     <h4 className="font-bold text-white text-base">{review.clientName}</h4>
                     <p className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                       <svg className="w-3.5 h-3.5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                       </svg>
                       مراجعة موثقة بواسطة كوديار
                     </p>
                   </div>
                 </div>
                 
                 <div className="w-8 h-8 rounded-full bg-[#1A1A24] flex items-center justify-center border border-white/5">
                   <svg className="w-4 h-4 text-[#C1A87D]" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20.283 10.356h-8.327v3.451h4.792c-.446 2.193-2.313 3.453-4.792 3.453a5.27 5.27 0 0 1-5.279-5.28 5.27 5.27 0 0 1 5.279-5.279c1.259 0 2.397.447 3.29 1.178l2.6-2.599c-1.584-1.381-3.615-2.233-5.89-2.233a8.908 8.908 0 0 0-8.934 8.934 8.907 8.907 0 0 0 8.934 8.934c4.467 0 8.529-3.249 8.529-8.934 0-.528-.081-1.097-.202-1.625z"></path>
                   </svg>
                 </div>
              </div>

              <div className="flex gap-1 mb-4 text-[#FADB14]">
                {[...Array(review.stars || 5)].map((_, i) => (
                  <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-[18px] h-[18px]">
                    <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96-1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                  </svg>
                ))}
              </div>
              
              <p className="text-slate-300 text-[15px] font-medium leading-relaxed flex-1">"{review.comment}"</p>
            </motion.div>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {modalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              onClick={() => setModalOpen(false)}
              className="absolute inset-0 bg-[#0B0F19]/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 25 }} 
              animate={{ opacity: 1, scale: 1, y: 0 }} 
              exit={{ opacity: 0, scale: 0.95, y: 25 }}
              className="relative w-full max-w-lg bg-white border border-[#EAE6DF] rounded-[2rem] p-8 shadow-2xl z-10 text-right overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-full h-2 bg-gradient-to-r from-[#1F1C18] to-[#C1A87D]"></div>
              <h3 className="text-2xl font-black text-[#1F1C18] mb-3 mt-2">شاركنا تجربتك معنا</h3>
              <p className="text-[#645C51] text-sm mb-8 font-medium">نحن نفتخر بمساهمتنا في نجاح علامتك التجاري. تفضل بكتابة آرائك لدعم طموحنا.</p>

              {submitted ? (
                <div className="py-12 text-center">
                  <div className="w-20 h-20 bg-green-500/10 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6 text-3xl font-black">✓</div>
                  <h4 className="text-2xl font-black text-[#1F1C18] mb-3">تم رفع المراجعة</h4>
                  <p className="text-[#645C51] text-[15px] font-medium leading-relaxed">شكراً جزيلاً لك! ستظهر مراجعتك ضمن شركاء النجاح فور توثيقها من قبل الإدارة.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmitReview} className="space-y-6 text-[#1F1C18]">
                  <div>
                    <label className="block text-xs font-bold text-[#8B8476] mb-2 uppercase tracking-wide">الاسم الكامل / اسم النشاط التجاري</label>
                    <input 
                      type="text" 
                      required
                      value={name} 
                      onChange={(e) => setName(e.target.value)} 
                      placeholder="امثلة: مطعم البارون, علي الكناني..." 
                      className="w-full text-base h-14 rounded-2xl border-2 border-[#EAE6DF] bg-[#FAF9F6] px-4 focus:ring-4 focus:ring-[#C1A87D]/10 outline-none text-[#1F1C18] font-semibold focus:border-[#C1A87D] transition-all" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[#8B8476] mb-2 uppercase tracking-wide">التقييم (من 5 نجوم)</label>
                    <div className="flex items-center gap-2 flex-row-reverse justify-end">
                      {[1,2,3,4,5].map(v => (
                        <button 
                          key={v} 
                          type="button" 
                          onClick={() => setRating(v)}
                          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${rating >= v ? 'bg-[#FADB14] text-white shadow-[0_5px_15px_rgba(250,219,20,0.3)] scale-110' : 'bg-[#FAF9F6] text-[#D0C0A8] border-2 border-[#EAE6DF] hover:border-[#D0C0A8]'}`}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6"><path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96-1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" /></svg>
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[#8B8476] mb-2 uppercase tracking-wide">تقييمك لمستوى الخدمة</label>
                    <textarea 
                      required
                      value={comment} 
                      onChange={(e) => setComment(e.target.value)} 
                      placeholder="كيف كانت تجربتك في التعامل مع فريق التطوير..." 
                      className="w-full text-base min-h-[140px] rounded-2xl border-2 border-[#EAE6DF] bg-[#FAF9F6] p-4 py-4 focus:ring-4 focus:ring-[#C1A87D]/10 outline-none text-[#1F1C18] font-semibold resize-none focus:border-[#C1A87D] transition-all" 
                    />
                  </div>
                  <div className="pt-4 flex justify-between gap-4">
                    <button 
                      type="button" 
                      onClick={() => setModalOpen(false)}
                      className="px-6 py-4 rounded-xl border-2 border-[#EAE6DF] text-[#8B8476] font-bold hover:bg-[#FAF9F6] hover:text-[#1F1C18] transition-colors w-[120px]"
                    >
                      إلغاء
                    </button>
                    <button 
                      type="submit" 
                      disabled={submitting}
                      className="px-6 py-4 rounded-xl bg-[#1F1C18] text-[#F3E6D5] font-black flex-1 hover:bg-[#332E27] shadow-xl shadow-[#1F1C18]/20 active:scale-[0.98] transition-all disabled:opacity-50"
                    >
                      {submitting ? 'جاري الإرسال للتأكيد...' : 'نشر واعتماد التقييم'}
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}

export default function Home() {
  return (
    <div className="overflow-hidden">
      <HeroSection />
      <PackagesSection />
      <PortfolioSection />
      <TestimonialsSection />
    </div>
  );
}
