import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";
import { collection, query, where, getDocs, doc, updateDoc } from "firebase/firestore";
import type { Order, Project } from "../types";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "../components/ui/Button";
import { motion, AnimatePresence } from "motion/react";
import QRCode from "react-qr-code";
import { 
  FileText, 
  CreditCard, 
  Settings, 
  ArrowUpRight, 
  Crown, 
  Briefcase, 
  Check, 
  User, 
  Phone, 
  Mail, 
  Globe, 
  Calendar, 
  Clock, 
  Sparkles, 
  RefreshCw, 
  PlusCircle, 
  AlertTriangle, 
  MessageSquare, 
  Trash2,
  ScanQrCode,
  X 
} from "lucide-react";

export default function ClientDashboard() {
  const { user, dbUser, loading } = useAuth();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [fetching, setFetching] = useState(true);
  
  // Project settings states
  const [expandedProjectId, setExpandedProjectId] = useState<string | null>(null);
  const [requestedUpgrade, setRequestedUpgrade] = useState("");
  const [requestedDuration, setRequestedDuration] = useState("");
  const [featuresRequest, setFeaturesRequest] = useState("");
  
  // UI Toast states
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<"success" | "error">("success");
  const [showConfirmCancel, setShowConfirmCancel] = useState<string | null>(null);

  // QR Modal State
  const [showQrForInvoice, setShowQrForInvoice] = useState<string | null>(null);

  const PRODUCTION_URL = "https://ais-pre-fwflbzrhdo74kyrriph7ic-914508587929.europe-west2.run.app";

  const triggerToast = (msg: string, type: "success" | "error" = "success") => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 5000);
  };

  useEffect(() => {
    if (!loading && !user) navigate("/");
    if (!loading && dbUser?.role === 'admin') navigate("/admin");
  }, [user, loading, navigate, dbUser]);

  const fetchData = async () => {
    if (user) {
      try {
        const qOrders = query(collection(db, "orders"), where("clientId", "==", user.uid));
        const snapOrders = await getDocs(qOrders);
        setOrders(snapOrders.docs.map(d => d.data() as Order));

        const qProjects = query(collection(db, "projects"), where("clientId", "==", user.uid));
        const snapProjects = await getDocs(qProjects);
        setProjects(snapProjects.docs.map(d => d.data() as Project));
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, 'dashboard-data');
      } finally {
        setFetching(false);
      }
    }
  };

  useEffect(() => {
    fetchData();
  }, [user]);

  // Compute stats
  const activePackage = projects.length > 0 ? projects[0].package : "لا توجد باقة نشطة";
  const accountStatus = projects.length > 0 ? "نشط ومفعل" : "بانتظار مشروعك الأول";

  const calculateRemainingDays = (expirationDate?: number) => {
    if (!expirationDate) return 0;
    const diffTime = expirationDate - Date.now();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  // Upgrading Package
  const handleUpgradePackage = async (projectId: string) => {
    if (!requestedUpgrade) {
      triggerToast("يرجى اختيار الباقة المراد الترقية إليها.", "error");
      return;
    }
    try {
      await updateDoc(doc(db, "projects", projectId), {
        requestedUpgrade,
        updatedAt: Date.now()
      });
      triggerToast("تم إرسال طلب ترقية الباقة للإدارة بنجاح. سيتم التواصل معك قريباً!");
      
      // WhatsApp message for upgrade
      const msg = `مرحباً كوديار تك، أود ترقية مشروعي (${projects.find(p => p.id === projectId)?.name}) إلى الباقة: ${requestedUpgrade}.`;
      window.open(`https://wa.me/9647892966486?text=${encodeURIComponent(msg)}`, '_blank');
      fetchData();
    } catch (err) {
      triggerToast("حدث خطأ في معالجة طلبك، يرجى المحاولة لاحقاً.", "error");
    }
  };

  // Changing Duration
  const handleChangeDuration = async (projectId: string) => {
    if (!requestedDuration) {
      triggerToast("يرجى اختيار مدة الاشتراك المطلوبة.", "error");
      return;
    }
    try {
      await updateDoc(doc(db, "projects", projectId), {
        requestedDuration,
        updatedAt: Date.now()
      });
      triggerToast("تم إرسال طلب تجديد وتغيير مدة الاشتراك للإدارة.");
      
      const msg = `مرحباً كوديار تك، أود تمديد/تغيير اشتراك مشروعي (${projects.find(p => p.id === projectId)?.name}) إلى مدة: ${requestedDuration}.`;
      window.open(`https://wa.me/9647892966486?text=${encodeURIComponent(msg)}`, '_blank');
      fetchData();
    } catch (err) {
      triggerToast("حدث خطأ في معالجة طلبك.", "error");
    }
  };

  // Request Feature
  const handleRequestFeatures = async (projectId: string) => {
    if (!featuresRequest.trim()) {
      triggerToast("يرجى كتابة الميزات التي تود إضافتها أولاً.", "error");
      return;
    }
    try {
      await updateDoc(doc(db, "projects", projectId), {
        featuresRequest: featuresRequest.trim(),
        updatedAt: Date.now()
      });
      triggerToast("تم تسجيل طلب الميزات الإضافية. سيقوم فريقنا بالبدء فيها فور التنسيق!");
      
      const msg = `مرحباً كوديار تك، أود طلب ميزات مخصصة لمشروعي (${projects.find(p => p.id === projectId)?.name}):\n${featuresRequest}`;
      window.open(`https://wa.me/9647892966486?text=${encodeURIComponent(msg)}`, '_blank');
      setFeaturesRequest("");
      fetchData();
    } catch (err) {
      triggerToast("حدث خطأ أثناء إرسال طلب الميزات.", "error");
    }
  };

  // Cancel subscription
  const handleCancelSubscription = async (projectId: string) => {
    try {
      await updateDoc(doc(db, "projects", projectId), {
        status: "cancelled",
        statusList: ["cancelled"],
        updatedAt: Date.now()
      });
      triggerToast("تم إلغاء الاشتراك وإرسال إشعار الدعم الفني لتسوية المشروع.", "error");
      
      const msg = `مرحباً كوديار تك، أود طلب إلغاء اشتراكي لمشروعي المسمى (${projects.find(p => p.id === projectId)?.name}).`;
      window.open(`https://wa.me/9647892966486?text=${encodeURIComponent(msg)}`, '_blank');
      
      setShowConfirmCancel(null);
      fetchData();
    } catch (err) {
      triggerToast("فشل إلغاء الاشتراك.", "error");
    }
  };

  // Rendering project stamps correctly representing multi-status
  const renderProjectStamps = (p: Project) => {
    const list = p.statusList || [p.status];
    return (
      <div className="flex flex-wrap gap-2">
        {list.map((st) => {
          let label = "قيد المراجعة";
          let css = "bg-yellow-500/10 text-yellow-500 border border-yellow-500/20";
          
          if (st === "active" || st === "mktmal" || st === "مكتمل") {
            label = "مكتمل";
            css = "bg-green-500/10 text-green-500 border border-green-500/20";
          } else if (st === "development" || st === "قيد التطوير") {
            label = "قيد التطوير";
            css = "bg-blue-500/10 text-brand-blue border border-brand-blue/20";
          } else if (st === "pending" || st === "قيد المراجعة") {
            label = "قيد المراجعة";
            css = "bg-amber-500/10 text-brand-orange border border-brand-orange/20";
          } else if (st === "suspended" || st === "معلق") {
            label = "معلق";
            css = "bg-red-500/10 text-red-500 border border-red-500/30";
          } else if (st === "cancelled" || st === "ملغي" || st === "تم إلغاء الطلب") {
            label = "تم إلغاء الطلب";
            css = "bg-slate-500/10 text-slate-400 border border-slate-700/30";
          } else if (st === "paid" || st === "مدفوع") {
            label = "مدفوع";
            css = "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
          } else {
            label = st;
          }
          return (
            <span key={st} className={`text-[10px] sm:text-xs px-2.5 py-1 rounded-full font-extrabold tracking-wide ${css}`}>
              {label}
            </span>
          );
        })}
      </div>
    );
  };

  if (loading || fetching) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-brand-text-secondary bg-[#0B0F19] gap-3">
        <div className="w-12 h-12 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
        <p className="font-bold text-lg select-none">جاري مزامنة بيانات حسابك الموقر...</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      
      {/* Dynamic Success/Error Toast notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-24 left-4 right-4 md:left-auto md:right-8 z-50 max-w-sm"
          >
            <div className={`p-4 rounded-2xl border shadow-2xl flex items-center gap-3 ${
              toastType === 'success' ? 'bg-[#064E3B]/95 text-emerald-100 border-[#059669]' : 'bg-[#7F1D1D]/95 text-red-100 border-[#DC2626]'
            }`}>
              <div className="p-1 rounded-full bg-black/20 shrink-0">
                <Check size={16} />
              </div>
              <p className="font-bold text-sm leading-relaxed">{toastMessage}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* QR Code Verification Modal */}
      <AnimatePresence>
        {showQrForInvoice && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-brand-bg-secondary border border-brand-border rounded-3xl p-6 md:p-8 w-full max-w-sm shadow-2xl relative flex flex-col items-center text-center"
            >
              <button 
                onClick={() => setShowQrForInvoice(null)}
                className="absolute top-4 left-4 text-brand-text-secondary hover:text-white bg-brand-bg-primary hover:bg-red-500/10 p-2 rounded-full transition-colors"
              >
                <X size={18} />
              </button>
              
              <div className="w-14 h-14 bg-[#3b82f6]/10 text-brand-blue rounded-full flex items-center justify-center mb-5">
                <ScanQrCode size={28} />
              </div>
              
              <h3 className="text-xl font-black text-white mb-2">امسح رمز التحقق</h3>
              <p className="text-brand-text-secondary text-xs font-semibold mb-6">
                استخدم كاميرا هاتفك المحمول لمسح الرمز أدناه وعرض تفاصيل وتوثيق الفاتورة.
              </p>
              
              <div className="bg-white p-4 rounded-2xl shadow-xl w-full flex items-center justify-center">
                 <QRCode value={`${window.location.origin}/verify/${showQrForInvoice}`} size={200} level="Q" />
              </div>
              
              <div className="mt-6 text-xs text-slate-500 font-mono flex items-center gap-2 bg-[#0B0F19] px-4 py-2 rounded-xl border border-brand-border">
                <span className="text-brand-orange font-bold uppercase tracking-widest text-[9px]">ID:</span>
                {showQrForInvoice}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* TOP USER PROFILE SECTION - REDESIGNED PREMIUM */}
      <motion.div 
        initial={{ opacity: 0, y: -15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-[#111827] via-[#0F172A] to-[#020617] border border-[#1E293B] rounded-3xl p-6 sm:p-10 mb-12 shadow-xl relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#3b82f6]/10 rounded-full blur-3xl -mr-20 -mt-20"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#f97316]/5 rounded-full blur-3xl -ml-20 -mb-20"></div>
        
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 relative z-10">
          <div className="flex flex-col sm:flex-row items-center gap-6 text-center sm:text-right w-full lg:w-auto">
            {/* Deluxe Avatar Circle */}
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-tr from-[#3b82f6] to-[#F97316] p-1 shadow-2xl">
              <div className="w-full h-full bg-[#0B0F19] rounded-[14px] flex items-center justify-center text-white">
                <User size={40} className="text-slate-300" />
              </div>
            </div>

            <div className="space-y-1.5">
              <h1 className="text-3xl font-black text-white tracking-tight">{dbUser?.name}</h1>
              <div className="flex flex-col sm:flex-row sm:items-center gap-3 text-sm text-slate-400 font-semibold">
                <span className="flex items-center gap-1.5 justify-center sm:justify-start">
                  <Mail size={14} className="text-[#3b82f6]" /> {dbUser?.email}
                </span>
                <span className="hidden sm:inline text-slate-600">|</span>
                <span className="flex items-center gap-1.5 justify-center sm:justify-start font-mono" dir="ltr">
                  <Phone size={14} className="text-[#F97316]" /> {dbUser?.phone || "لا يوجد هاتف"}
                </span>
              </div>
              <div className="pt-2 flex flex-wrap gap-2 justify-center sm:justify-start">
                <span className="bg-[#3b82f6]/10 text-[#3b82f6] border border-[#3b82f6]/20 text-xs px-3 py-1 rounded-lg font-bold">
                  الباقة الفعالة: {activePackage}
                </span>
                <span className="bg-[#10B981]/10 text-[#10B981] border border-[#10B981]/20 text-xs px-3 py-1 rounded-lg font-bold">
                  الحالة: {accountStatus}
                </span>
              </div>
            </div>
          </div>

          <div className="shrink-0 w-full lg:w-auto flex flex-col sm:flex-row gap-4 justify-stretch">
            <Link to="/order" className="w-full sm:w-auto">
              <Button className="w-full bg-[#3b82f6] hover:bg-[#2563EB] text-white shadow-lg shadow-blue-500/20 py-6 px-8 rounded-xl font-bold text-sm tracking-wide">
                <PlusCircle size={18} className="ml-2 shrink-0" />
                طلب مشروع رقمي جديد
              </Button>
            </Link>
          </div>
        </div>
      </motion.div>

      {/* DASHBOARD GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* RIGHT COLUMN: MY PROJECTS (LUXURY BENTO CARD STYLE) */}
        <div className="lg:col-span-8 space-y-8">
          
          <section className="bg-brand-bg-secondary rounded-3xl border border-brand-border p-6 sm:p-8 shadow-sm">
            <div className="flex justify-between items-center mb-8 border-b border-brand-border pb-4">
              <div>
                <h2 className="text-2xl font-bold text-brand-text-primary tracking-tight">مشاريعي الرقمية</h2>
                <p className="text-xs text-brand-text-secondary mt-1 font-semibold">توسيع المشروع لإدارته وطلب الترقية وإرسال رسائل التحديث المباشرة.</p>
              </div>
            </div>

            {projects.length === 0 ? (
              <div className="text-center py-20 bg-brand-bg-primary rounded-2xl border border-dashed border-brand-border">
                <div className="w-16 h-16 bg-brand-blue/10 text-brand-blue rounded-full flex items-center justify-center mx-auto mb-4">
                  <Briefcase size={26} />
                </div>
                <h3 className="text-lg font-bold text-brand-text-primary mb-2">ليس لديك أي مشاريع بعد!</h3>
                <p className="text-brand-text-secondary text-sm max-w-sm mx-auto mb-6 leading-relaxed font-semibold">ابدأ رحلتك وصمم أول هوية رقمية متكاملة لعيادتك، مطعمك، أو متجرك معنا الآن.</p>
                <Link to="/order">
                  <Button size="sm">اطلب مشروعك الأول</Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-4">
                {projects.map(p => {
                  const isExpanded = expandedProjectId === p.id;
                  const remainingDays = calculateRemainingDays(p.expirationDate);
                  
                  return (
                    <div 
                      key={p.id} 
                      className={`rounded-2xl border transition-all duration-300 overflow-hidden ${
                        isExpanded ? 'border-[#3b82f6] shadow-xl bg-brand-bg-primary/55' : 'border-brand-border bg-brand-bg-primary hover:border-slate-500'
                      }`}
                    >
                      {/* Project Row Header */}
                      <div 
                        onClick={() => {
                          setExpandedProjectId(isExpanded ? null : p.id);
                          setRequestedUpgrade("");
                          setRequestedDuration("");
                          setFeaturesRequest("");
                        }}
                        className="p-5 sm:p-6 cursor-pointer flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4 select-none"
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-extrabold text-[#3b82f6] text-xl border transition-all shrink-0 ${
                            isExpanded ? 'bg-[#3b82f6]/15 border-[#3b82f6]' : 'bg-brand-bg-secondary border-brand-border'
                          }`}>
                            <span style={{ fontFamily: "Inter" }}>{p.name?.charAt(0) || "P"}</span>
                          </div>
                          <div>
                            <h3 className="font-extrabold text-lg text-brand-text-primary group-hover:text-[#3b82f6] transition-colors">{p.name}</h3>
                            <p className="text-xs text-brand-text-secondary font-semibold mt-0.5">{p.type} • {p.package}</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between sm:justify-end gap-4 border-t sm:border-t-0 border-brand-border/40 pt-3 sm:pt-0">
                          {renderProjectStamps(p)}
                          <div className="text-brand-text-secondary">
                            <span className="text-xs font-bold leading-none bg-brand-bg-secondary px-2.5 py-1.5 rounded-lg border border-brand-border">
                              {isExpanded ? "إغلاق التفاصيل ▲" : "توسيع ومزايا ▼"}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Project Expanded Body Layout */}
                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: "auto" }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.3 }}
                            className="bg-[#0f172a]/20 border-t border-brand-border/80 px-6 py-8 space-y-8"
                          >
                            
                            {/* Section: Project core metadata bento */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                              <div className="bg-brand-bg-secondary p-4 rounded-xl border border-brand-border">
                                <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">فئة ونوع المشروع</span>
                                <span className="text-brand-text-primary font-bold text-sm mt-1 block">{p.type}</span>
                              </div>
                              <div className="bg-brand-bg-secondary p-4 rounded-xl border border-brand-border">
                                <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">باقة الاشتراك</span>
                                <span className="text-brand-text-primary font-bold text-sm mt-1 block text-brand-blue">{p.package}</span>
                              </div>
                              <div className="bg-brand-bg-secondary p-4 rounded-xl border border-brand-border">
                                <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">الأيام المتبقية للاشتراك</span>
                                <span className={`font-black text-sm mt-1 block ${remainingDays <= 7 ? "text-red-500" : "text-emerald-400"}`}>
                                  {remainingDays} يوم
                                </span>
                              </div>
                              <div className="bg-brand-bg-secondary p-4 rounded-xl border border-brand-border flex flex-col justify-center">
                                <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">رابط وعنوان الويب</span>
                                {p.url ? (
                                  <a href={p.url} target="_blank" rel="noreferrer" className="text-[#3b82f6] font-bold text-xs mt-1 hover:underline flex items-center gap-1">
                                    زيارة الموقع الإلكتروني <Globe size={12} />
                                  </a>
                                ) : (
                                  <span className="text-xs text-amber-500 font-bold mt-1">جاري ربط الدومين مع خوادمنا...</span>
                                )}
                              </div>
                            </div>

                            {/* Verification information list */}
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-brand-bg-secondary border border-brand-border">
                              <div className="flex flex-col sm:flex-row sm:items-center gap-6 font-semibold text-xs text-brand-text-secondary">
                                <span className="flex items-center gap-1.5">
                                  <Calendar size={14} className="text-slate-500" /> تاريخ التفعيل:{" "}
                                  <span className="text-brand-text-primary font-bold">
                                    {p.activationDate ? new Date(p.activationDate).toLocaleDateString('ar-IQ') : "بانتظار التجديد"}
                                  </span>
                                </span>
                                <span className="hidden sm:inline text-slate-800">|</span>
                                <span className="flex items-center gap-1.5">
                                  <Clock size={14} className="text-slate-500" /> تاريخ الانتهاء الصلاحية:{" "}
                                  <span className="text-brand-text-primary font-bold">
                                    {p.expirationDate ? new Date(p.expirationDate).toLocaleDateString('ar-IQ') : "لا يوجد"}
                                  </span>
                                </span>
                              </div>
                              <Link to={`/receipt/${p.id}`}>
                                <Button variant="outline" size="xs" className="border-brand-border text-brand-text-primary hover:bg-brand-bg-secondary font-bold text-xs gap-1">
                                  <FileText size={12} className="text-brand-orange" />
                                  عرض مستند تفاصيل الاستلام
                                </Button>
                              </Link>
                            </div>

                            {/* Section: Project Settings Forms */}
                            <div className="border-t border-brand-border/40 pt-6">
                              <h4 className="text-sm font-bold text-brand-text-primary mb-4 flex items-center gap-2">
                                <Settings size={16} className="text-[#3b82f6]" />
                                إعدادات المشروع وخيارات الخدمة المباشرة
                              </h4>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6">
                                {/* Form: Upgrade Package */}
                                <div className="space-y-2 bg-[#111827]/30 p-5 rounded-xl border border-brand-border">
                                  <label className="text-xs font-bold text-brand-text-secondary block">طلب ترقية باقة المشروع</label>
                                  <div className="flex gap-2">
                                    <select 
                                      value={requestedUpgrade}
                                      onChange={(e) => setRequestedUpgrade(e.target.value)}
                                      className="flex-1 text-xs h-10 rounded-lg border border-brand-border bg-brand-bg-secondary px-3 focus:ring-2 outline-none text-brand-text-primary"
                                    >
                                      <option value="">اختر باقة فاخرة...</option>
                                      <option value="الباقة الذهبية (Gold)">الباقة الذهبية (Gold) - 19,000 د.ع/ش</option>
                                      <option value="الباقة الاحترافية (Pro)">الباقة الاحترافية (Pro) - 39,000 د.ع/ش</option>
                                      <option value="الباقة الفاخرة (Premium)">الباقة الفاخرة (Premium) - 79,000 د.ع/ش</option>
                                    </select>
                                    <Button onClick={() => handleUpgradePackage(p.id)} size="sm" className="bg-[#3b82f6] hover:bg-blue-600 h-10 px-4 text-xs font-bold shrink-0">
                                      طلب ترقية
                                    </Button>
                                  </div>
                                </div>

                                {/* Form: Change subscription duration */}
                                <div className="space-y-2 bg-[#111827]/30 p-5 rounded-xl border border-brand-border">
                                  <label className="text-xs font-bold text-brand-text-secondary block">تمديد / تغيير دورة الاشتراك</label>
                                  <div className="flex gap-2">
                                    <select 
                                      value={requestedDuration}
                                      onChange={(e) => setRequestedDuration(e.target.value)}
                                      className="flex-1 text-xs h-10 rounded-lg border border-brand-border bg-brand-bg-secondary px-3 focus:ring-2 outline-none text-brand-text-primary"
                                    >
                                      <option value="">اختر حزمة الأشهر...</option>
                                      <option value="1 شهر">1 شهر (بدون خصم)</option>
                                      <option value="3 أشهر (خصم 5%)">3 أشهر (خصم 5%)</option>
                                      <option value="6 أشهر (خصم 10%)">6 أشهر (خصم 10%)</option>
                                      <option value="12 شهر (خصم 25%)">12 شهر (خصم 25% سنوي)</option>
                                    </select>
                                    <Button onClick={() => handleChangeDuration(p.id)} size="sm" className="bg-[#3b82f6] hover:bg-blue-600 h-10 px-4 text-xs font-bold shrink-0">
                                      تمديد المدة
                                    </Button>
                                  </div>
                                </div>
                              </div>

                              {/* Form: Request new custom features */}
                              <div className="space-y-3 bg-[#111827]/30 p-5 rounded-xl border border-brand-border mb-6">
                                <label className="text-xs font-bold text-brand-text-secondary flex items-center gap-1.5">
                                  <MessageSquare size={14} className="text-brand-orange" />
                                  اطلب مميزات تقنية إضافية، تعديلات أو إضافات برمجية مخصصة للعلامة الخاصة بك
                                </label>
                                <textarea 
                                  value={featuresRequest} 
                                  onChange={(e) => setFeaturesRequest(e.target.value)}
                                  rows={2} 
                                  placeholder="مثال: أود إضافة نظام الدفع ببطاقات زين كاش لمتجري، إتاحة طلب مسبق للعيادة، إضافة حجز مباشر..." 
                                  className="w-full text-xs rounded-lg border border-brand-border bg-brand-bg-secondary px-3 py-2 outline-none text-brand-text-primary resize-none focus:ring-1 focus:ring-[#3b82f6]"
                                ></textarea>
                                <div className="flex justify-end">
                                  <Button onClick={() => handleRequestFeatures(p.id)} size="sm" className="bg-[#F97316] hover:bg-[#EA580C] px-5 h-9 text-xs font-bold">
                                    إرسال طلب ميزات إضافية
                                  </Button>
                                </div>
                              </div>

                              {/* Form: Cancel subscription section */}
                              <div className="bg-red-500/5 border border-red-500/10 p-5 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                <div>
                                  <h5 className="text-xs font-bold text-red-400">إلغاء اشتراك الهوية الرقمية</h5>
                                  <p className="text-[10px] text-brand-text-secondary mt-0.5 font-semibold">سيترتب على إلغاء الخدمة توقف خوادم الموقع الخاص بك وحذف حساب السحابة المعتمد.</p>
                                </div>
                                {showConfirmCancel === p.id ? (
                                  <div className="flex items-center gap-2">
                                    <button 
                                      onClick={() => handleCancelSubscription(p.id)}
                                      className="text-[11px] font-bold px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white"
                                    >
                                      تأكيد الإلغاء والقطع
                                    </button>
                                    <button 
                                      onClick={() => setShowConfirmCancel(null)}
                                      className="text-[11px] font-bold px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300"
                                    >
                                      تراجع
                                    </button>
                                  </div>
                                ) : (
                                  <button 
                                    onClick={() => setShowConfirmCancel(p.id)}
                                    className="text-[11px] font-bold px-4 py-2 rounded-lg border border-red-500/30 hover:bg-red-500/10 text-red-400 flex items-center gap-1 self-start sm:self-auto shrink-0 transition-colors"
                                  >
                                    <Trash2 size={12} />
                                    إلغاء الخدمة والاشتراك
                                  </button>
                                )}
                              </div>
                            </div>

                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </div>

        {/* LEFT COLUMN: TRANSACTION HISTORY */}
        <div className="lg:col-span-4 space-y-8">
          
          <section className="bg-brand-bg-secondary rounded-3xl border border-brand-border p-6 shadow-sm">
            <h3 className="text-xl font-bold text-brand-text-primary tracking-tight mb-6 pb-2 border-b border-brand-border">
              سجل الطلبات والمدفوعات
            </h3>

            {orders.length === 0 ? (
              <div className="py-12 text-center text-brand-text-secondary font-semibold text-xs">
                لا توجد دفعات جارية.
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map(o => (
                  <div key={o.id} className="p-4 rounded-xl border border-brand-border bg-brand-bg-primary/50 relative flex items-center justify-between">
                    <div>
                      <span className="font-mono text-xs text-[#3b82f6] font-bold tracking-wider">{o.id}</span>
                      <h4 className="text-sm font-extrabold text-brand-text-primary mt-1 line-clamp-1">{o.projectName}</h4>
                      <div className="flex items-center gap-2 mt-2 font-semibold">
                        <span className="text-xs text-brand-text-primary font-mono" dir="ltr">{o.total.toLocaleString()} د.ع</span>
                        <span className="text-[10px] text-slate-500">•</span>
                        <span className="text-[10px] text-slate-400 font-mono">{new Date(o.createdAt).toLocaleDateString('en-GB')}</span>
                      </div>
                      
                      {o.adminNotes && (
                        <div className="mt-3 text-[11px] bg-brand-orange/5 border border-brand-orange/30 p-2 rounded-lg text-brand-text-primary max-w-xs xl:max-w-max">
                           <span className="font-bold block text-brand-orange mb-0.5">رد الإدارة:</span>
                           {o.adminNotes}
                        </div>
                      )}
                    </div>

                    <div className="flex flex-col items-end gap-2.5">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-extrabold ${
                        o.status === "paid" ? "bg-green-500/10 text-green-500" : "bg-orange-500/10 text-brand-orange"
                      }`}>
                        {o.status === "paid" ? "تم دفع الفاتورة" : "بانتظار السداد"}
                      </span>
                      <div className="flex items-center gap-2">
                        <Button 
                          onClick={() => setShowQrForInvoice(o.id)}
                          size="xs" 
                          variant="outline" 
                          className="text-[10px] px-2 py-1 h-7 font-bold border-brand-border text-brand-text-primary bg-[#111827]/80 hover:bg-[#1E293B]"
                        >
                          <ScanQrCode size={10} className="mr-0.5" />
                          رمز QR
                        </Button>
                        <Link to={`/receipt/${o.id}`}>
                          <Button size="xs" variant="outline" className="text-[10px] px-2 py-1 h-7 font-bold border-brand-border text-brand-text-primary">
                            عرض الفاتورة
                            <ArrowUpRight size={10} className="mr-0.5" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* SUPPORT AND CONTACT CARD WHATSAPP AS REQUESTED */}
          <div className="bg-gradient-to-br from-[#1E293B] to-[#0B0F19] p-6 rounded-3xl border border-[#303F58] relative overflow-hidden text-center">
            <div className="w-12 h-12 bg-white/5 text-white rounded-full flex items-center justify-center mx-auto mb-4 border border-white/10 shadow">
              <Phone size={20} className="text-[#3b82f6]" />
            </div>
            <h4 className="font-extrabold text-lg text-white mb-1.5">الدعم الفني والبرمجة</h4>
            <p className="text-xs text-slate-400 font-semibold mb-6 leading-relaxed max-w-xs mx-auto">هل تواجه مشكلة أو تحتاج لاستشارة فنية؟ فريق كوديار تك على واتساب جاهز لخدمتك على مدار الساعة.</p>
            <a href="https://wa.me/9647892966486" target="_blank" rel="noreferrer">
              <Button size="sm" className="w-full bg-[#10B981] hover:bg-[#059669] text-white border-none font-bold shadow shadow-emerald-600/15 py-5 rounded-xl">
                فتح محادثة واتساب المباشرة
              </Button>
            </a>
          </div>

        </div>

      </div>
    </div>
  );
}
