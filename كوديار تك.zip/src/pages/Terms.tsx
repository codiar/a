import { motion } from "motion/react";
import { FileText } from "lucide-react";

export default function Terms() {
  return (
    <div className="py-24 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-16 text-center"
      >
        <div className="w-20 h-20 bg-brand-bg-secondary rounded-2xl flex items-center justify-center mx-auto mb-6 border border-brand-border shadow-sm">
          <FileText size={36} className="text-brand-text-primary" />
        </div>
        <h1 className="text-4xl font-black text-brand-text-primary mb-4 tracking-tight">شروط الخدمة</h1>
        <p className="text-brand-text-secondary font-medium">الرجاء قراءة هذه الشروط بعناية قبل استخدام خدماتنا</p>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-brand-bg-secondary border border-brand-border rounded-[2.5rem] p-8 md:p-12 prose prose-invert max-w-none text-brand-text-secondary leading-relaxed"
      >
        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">1. قبول الشروط</h2>
        <p className="mb-8 font-medium">
          باستخدامك لموقع ومنصة كوديار تك لطلب خدمات البرمجة والتصميم، فإنك توافق على الالتزام بشروط الخدمة هذه. إذا كنت لا توافق على أي من هذه الشروط، يرجى عدم استخدام المنصة.
        </p>

        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">2. وصف الخدمة</h2>
        <p className="mb-8 font-medium">
          كوديار تك هي وكالة برمجية تقدم خدمات تصميم المواقع الإلكترونية، تطوير الأنظمة والمنصات، إعداد المنافذ الإلكترونية (القوائم الرقمية)، وتصاميم الهوية البصرية والمستندات التقنية.
        </p>

        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">3. الدفع والاسترداد</h2>
        <ul className="list-disc pr-6 mb-8 font-medium space-y-2">
          <li>يبدأ العمل الفعلي بعد دفع العربون (الدفعة الأولى) المتفق عليه والذي يمثل 50% كحد أدنى من قيمة المشروع.</li>
          <li>الدفعة الأولى غير قابلة للاسترداد بعد البدء في تنفيذ المشروع وتخصيص الموارد التقنية.</li>
          <li>تسلم النسخة النهائية من المشروع ورموزه البرمجية الأساسية (للأنظمة الخاصة) بعد سداد كامل المبلغ المتبقي.</li>
        </ul>

        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">4. التعديلات ودعم ما بعد التسليم</h2>
        <ul className="list-disc pr-6 mb-8 font-medium space-y-2">
          <li>يحق للعميل طلب تعديلات ضمن نطاق الاتفاق الأساسي المكتوب في عقد العمل بدون رسوم إضافية.</li>
          <li>أي متطلبات أو ميزات جديدة يتم طلبها بعد الاتفاق تعتبر "طلب عمل إضافي" وسيتم تسعيرها بشكل منفصل.</li>
          <li>نقدم دعمًا فنيًا لإصلاح الأخطاء البرمجية (Bugs) لمدة مجانية تحدد حسب باقة الاشتراك.</li>
        </ul>

        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">5. حدود المسؤولية</h2>
        <p className="font-medium">
          كوديار تك غير مسؤولة عن أية أضرار عرضية أو غير مباشرة ناتجة عن الأعطال الخفية الخارجة عن سيطرتنا المباشرة بعد تسليم وتشغيل الأنظمة للعميل على خوادمه أو استضافته الخاصة.
        </p>
      </motion.div>
    </div>
  )
}
