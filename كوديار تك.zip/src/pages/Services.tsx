import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { Monitor, Smartphone, PenTool, LayoutTemplate, Coffee, Zap } from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: <Monitor className="text-brand-blue" size={32} />,
      title: "تصميم وتطوير المواقع",
      desc: "مواقع إلكترونية متجاوبة، سريعة، ومبنية بأحدث تقنيات الويب العالمية لضمان أفضل تجربة للمستخدم وتصدر نتائج البحث.",
      features: ["تصميم UI/UX حصري", "دعم كامل للأجهزة المحمولة", "لوحة تحكم إدارية", "حماية وأمان عالي"],
      price: "يبدأ من 250,000 د.ع"
    },
    {
      icon: <Smartphone className="text-brand-orange" size={32} />,
      title: "المنيو الإلكتروني الذكي",
      desc: "قوائم طعام تفاعلية تدعم مسح QR Code، تساعد المطاعم والمقاهي على عرض منتجاتهم بأسلوب احترافي وجذاب.",
      features: ["تحديث فوري للأسعار", "دعم للصور والفيديوهات", "بدون تحميل تطبيقات", "إحصائيات تفصيلية للزيارات"],
      price: "يبدأ من 75,000 د.ع"
    },
    {
      icon: <LayoutTemplate className="text-purple-500" size={32} />,
      title: "بناء منصات البورتفوليو",
      desc: "مواقع شخصية مخصصة للمصممين، المبرمجين، والمبدعين لعرض أعمالهم بشكل أنيق يجذب العملاء.",
      features: ["معرض أعمال تفاعلي", "نماذج تواصل مباشرة", "ربط مع منصات التواصل", "تصميم يعكس هويتك"],
      price: "يبدأ من 150,000 د.ع"
    },
    {
      icon: <Coffee className="text-[#C1A87D]" size={32} />,
      title: "الدعوات الإلكترونية",
      desc: "دعوات زفاف وحفلات تخرج وبطاقات تهنئة إلكترونية بتصاميم فاخرة تصل للمدعوين عبر واتساب.",
      features: ["تصميم جذاب ومميز", "مؤثرات حركية", "تأكيد الحضور", "موسيقى أو صوتيات مخصصة"],
      price: "يبدأ من 50,000 د.ع"
    },
    {
      icon: <PenTool className="text-emerald-500" size={32} />,
      title: "تصميم الشعارات والهوية البصرية",
      desc: "بناء وتصميم هوية تجارية قوية ومؤثرة تعكس قيم شركتك، تتضمن الشعار والألوان والخطوط والأوراق الرسمية.",
      features: ["شعارات أصلية غير منسوخة", "دليل الهوية البصرية", "تصاميم سوشيال ميديا", "تسليم جميع الملفات المصدرية"],
      price: "حسب متطلبات المشروع"
    },
    {
      icon: <Zap className="text-red-500" size={32} />,
      title: "حلول برمجية مخصصة",
      desc: "تطوير أنظمة خاصة للشركات والمؤسسات لحل مشاكل معينة أو أتمتة العمليات اليومية لزيادة الإنتاجية.",
      features: ["تحليل كامل للنظام", "واجهات تطبيق ذكية", "قواعد بيانات سحابية", "دعم فني متواصل"],
      price: "يُحدد بعد دراسة المشروع"
    }
  ];

  return (
    <div className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-20"
      >
        <span className="text-brand-orange font-bold tracking-widest text-sm uppercase mb-4 block">حلولنا لك</span>
        <h1 className="text-4xl md:text-5xl font-black text-brand-text-primary mb-6">خدماتنا التكنولوجية</h1>
        <p className="text-xl text-brand-text-secondary max-w-2xl mx-auto font-medium leading-relaxed">
          نقدم مجموعة متكاملة من الخدمات الرقمية والبرمجية المصممة لرفع كفاءة أعمالك وإبراز تواجدك الرقمي.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((srv, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-brand-bg-secondary border border-brand-border rounded-3xl p-8 hover:-translate-y-2 transition-all duration-300 shadow-sm hover:shadow-xl flex flex-col h-full group"
          >
            <div className="w-16 h-16 bg-brand-bg-primary rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              {srv.icon}
            </div>
            <h3 className="text-2xl font-bold text-brand-text-primary mb-3">{srv.title}</h3>
            <p className="text-brand-text-secondary font-medium mb-6 flex-1 text-sm leading-relaxed">{srv.desc}</p>
            
            <div className="border-t border-brand-border/50 pt-5 mb-6">
              <h4 className="text-xs font-bold text-brand-text-primary mb-3 uppercase tracking-wider">أهم المميزات المرفقة</h4>
              <ul className="space-y-2">
                {srv.features.map((feat, i) => (
                  <li key={i} className="flex items-center text-sm text-brand-text-secondary font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-brand-text-primary mr-2 ml-2"></span>
                    {feat}
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="mt-auto flex items-center justify-between">
              <span className="text-brand-text-primary font-bold text-sm bg-brand-bg-primary px-3 py-1.5 rounded-lg border border-brand-border">{srv.price}</span>
              <Link to="/order">
                <button className="text-brand-bg-primary bg-brand-text-primary hover:bg-brand-text-secondary px-5 py-2 rounded-xl text-sm font-bold transition-colors">
                  طلب الخدمة
                </button>
              </Link>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
