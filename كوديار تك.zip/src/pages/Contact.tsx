import { motion } from "motion/react";
import { MessageCircle, Instagram, Send, Mail, Phone, ExternalLink } from "lucide-react";

export default function Contact() {
  const socialLinks = [
    {
      name: "WhatsApp",
      username: "+964 789 296 6486",
      icon: <Phone size={28} className="text-[#25D366]" />,
      url: "https://wa.me/9647892966486",
      color: "hover:border-[#25D366] hover:shadow-[0_0_20px_rgba(37,211,102,0.15)] group-hover:bg-[#25D366]/10"
    },
    {
      name: "Instagram",
      username: "@codiar_tech",
      icon: <Instagram size={28} className="text-[#E1306C]" />,
      url: "https://instagram.com/codiar_tech",
      color: "hover:border-[#E1306C] hover:shadow-[0_0_20px_rgba(225,48,108,0.15)] group-hover:bg-[#E1306C]/10"
    },
    {
      name: "Telegram",
      username: "@codiar_tech",
      icon: <Send size={28} className="text-[#0088cc]" />,
      url: "https://t.me/codiar_tech",
      color: "hover:border-[#0088cc] hover:shadow-[0_0_20px_rgba(0,136,204,0.15)] group-hover:bg-[#0088cc]/10"
    },
    {
      name: "TikTok",
      username: "@codiar_tech",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-brand-text-primary">
          <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"></path>
        </svg>
      ),
      url: "https://tiktok.com/@codiar_tech",
      color: "hover:border-brand-text-primary hover:shadow-[0_0_20px_rgba(150,150,150,0.15)] group-hover:bg-brand-text-primary/10"
    },
    {
      name: "البريد الإلكتروني",
      username: "codiartech@gmail.com",
      icon: <Mail size={28} className="text-brand-orange" />,
      url: "mailto:codiartech@gmail.com",
      color: "hover:border-brand-orange hover:shadow-[0_0_20px_rgba(249,115,22,0.15)] group-hover:bg-brand-orange/10"
    }
  ];

  return (
    <div className="py-24 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <div className="w-24 h-24 bg-brand-bg-secondary rounded-[2rem] border border-brand-border flex items-center justify-center mx-auto mb-8 shadow-xl">
          <MessageCircle size={40} className="text-brand-text-primary" />
        </div>
        <h1 className="text-4xl font-black text-brand-text-primary mb-4 tracking-tight">تواصل معنا</h1>
        <p className="text-lg text-brand-text-secondary font-medium">
          نحن هنا للإجابة على استفساراتك. تواصل معنا عبر قنواتنا الرسمية وسنرد عليك في أقرب وقت.
        </p>
      </motion.div>

      <div className="w-full space-y-4">
        {socialLinks.map((link, idx) => (
          <motion.a 
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`group flex items-center p-6 bg-brand-bg-secondary border border-brand-border rounded-3xl transition-all duration-300 w-full ${link.color.split(' ').filter(c => c.startsWith('hover')).join(' ')}`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center bg-brand-bg-primary border border-brand-border transition-colors duration-300 ${link.color.split(' ').find(c => c.startsWith('group-hover'))}`}>
              {link.icon}
            </div>
            
            <div className="mr-6 flex-1 text-right">
              <h3 className="text-xl font-bold text-brand-text-primary mb-1">{link.name}</h3>
              <p className="text-brand-text-secondary font-medium text-sm" dir="ltr">{link.username}</p>
            </div>
            
            <div className="w-10 h-10 rounded-full border border-brand-border flex items-center justify-center group-hover:bg-brand-text-primary group-hover:border-brand-text-primary group-hover:text-brand-bg-primary transition-colors text-brand-text-secondary">
              <ExternalLink size={16} className="-scale-x-100" />
            </div>
          </motion.a>
        ))}
      </div>
    </div>
  )
}
