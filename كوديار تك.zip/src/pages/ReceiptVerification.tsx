import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { doc, getDoc, collection, query, where, getDocs } from "firebase/firestore";
import { db } from "../lib/firebase";
import type { Order, Receipt as ReceiptType } from "../types";
import { motion } from "motion/react";
import { CodiarLogo } from "../components/brand/CodiarLogo";
import { Button } from "../components/ui/Button";
import { 
  CheckCircle2, 
  XOctagon, 
  Clock, 
  FileText, 
  User, 
  Briefcase, 
  Calendar,
  AlertTriangle
} from "lucide-react";
import { formatIraqiDinar } from "../lib/utils";

export default function ReceiptVerification() {
  const { id } = useParams<{id: string}>();
  const [receipt, setReceipt] = useState<ReceiptType | null>(null);
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    if (!id) return;

    const verifyReceipt = async () => {
      try {
        let rData: ReceiptType | null = null;
        let oData: Order | null = null;

        // Try getting by Order ID
        const q1 = query(collection(db, "orders"), where("id", "==", id));
        const os1 = await getDocs(q1);
        if (!os1.empty) {
          oData = os1.docs[0].data() as Order;
          // Get receipt
          if (oData.receiptId) {
            const rSnap = await getDoc(doc(db, "receipts", oData.receiptId));
            if (rSnap.exists()) rData = rSnap.data() as ReceiptType;
          } else {
            const rq1 = query(collection(db, "receipts"), where("orderId", "==", oData.id));
            const rs1 = await getDocs(rq1);
            if (!rs1.empty) rData = rs1.docs[0].data() as ReceiptType;
          }
        } 
        
        // Try getting by Receipt ID directly
        if (!rData) {
          const rSnap = await getDoc(doc(db, "receipts", id));
          if (rSnap.exists()) {
            rData = rSnap.data() as ReceiptType;
            const oSnap = await getDoc(doc(db, "orders", rData.orderId));
            if (oSnap.exists()) {
              oData = oSnap.data() as Order;
            }
          }
        }

        // Try getting by Document ID (Orders)
        if (!oData) {
          const oSnap = await getDoc(doc(db, "orders", id));
          if (oSnap.exists()) {
            oData = oSnap.data() as Order;
            const rq = query(collection(db, "receipts"), where("orderId", "==", oData.id));
            const rs = await getDocs(rq);
            if (!rs.empty) rData = rs.docs[0].data() as ReceiptType;
          }
        }

        if (rData && oData) {
          setReceipt(rData);
          setOrder(oData);
        } else {
          setError(true);
        }
      } catch (err) {
        console.error("Verification failed:", err);
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    verifyReceipt();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0B0F19] text-brand-text-secondary gap-4">
        <div className="w-12 h-12 border-4 border-brand-blue border-t-transparent rounded-full animate-spin"></div>
        <p className="font-bold text-lg select-none tracking-widest text-brand-blue">جاري التحقق والتوثيق...</p>
      </div>
    );
  }

  if (error || !receipt || !order) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0B0F19] p-4 text-center">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-brand-bg-secondary border border-brand-border rounded-3xl p-8 max-w-sm w-full shadow-2xl flex flex-col items-center"
        >
          <div className="w-20 h-20 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mb-6">
            <XOctagon size={40} />
          </div>
          <h2 className="text-2xl font-black mb-3 text-white">الفاتورة غير موجودة</h2>
          <p className="text-brand-text-secondary font-medium mb-8 text-sm leading-relaxed">
            تعذر العثور على الفاتورة المطلوبة. قد يكون الرابط غير صحيح أو تم مسح الفاتورة، يرجى التواصل مع الدعم للتحقق.
          </p>
          <Link to="/" className="w-full">
            <Button className="w-full bg-brand-bg-primary text-white border-brand-border">
              العودة للرئيسية
            </Button>
          </Link>
        </motion.div>
      </div>
    );
  }

  // Format Status
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
      case 'unpaid': return 'text-brand-orange bg-brand-orange/10 border-brand-orange/20';
      case 'cancelled': return 'text-red-500 bg-red-500/10 border-red-500/20';
      default: return 'text-brand-blue bg-brand-blue/10 border-brand-blue/20';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'paid': return 'مدفوعة ومكتملة';
      case 'unpaid': return 'بانتظار الدفع';
      case 'cancelled': return 'ملغاة';
      default: return 'قيد المراجعة';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid': return <CheckCircle2 size={16} className="text-emerald-500" />;
      case 'unpaid': return <Clock size={16} className="text-brand-orange" />;
      case 'cancelled': return <XOctagon size={16} className="text-red-500" />;
      default: return <AlertTriangle size={16} className="text-brand-blue" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F19] py-12 px-4 flex justify-center bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-900/10 via-[#0B0F19] to-[#0B0F19]">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="max-w-md w-full"
      >
        <div className="bg-brand-bg-secondary border border-brand-border rounded-[2rem] overflow-hidden shadow-2xl relative">
          
          {/* Header */}
          <div className="bg-brand-bg-primary/50 border-b border-brand-border p-6 flex flex-col items-center justify-center relative">
            <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-transparent via-brand-blue to-transparent opacity-50"></div>
            <CodiarLogo className="h-10 mb-4" />
            <h1 className="text-xl font-black tracking-tighter text-white">وثيقة مصادقة الفاتورة</h1>
            <p className="text-brand-text-secondary text-xs mt-1">نظام التوثيق والمصادقة المالي</p>
          </div>

          <div className="p-6 md:p-8 flex flex-col gap-6">
            
            {/* Status Section */}
            <div className="flex flex-col items-center justify-center p-6 bg-[#0B0F19] rounded-2xl border border-brand-border border-dashed relative overflow-hidden">
               {receipt.status === 'paid' && (
                 <div className="absolute -right-6 -top-6 w-24 h-24 bg-emerald-500/10 blur-2xl rounded-full"></div>
               )}
               <div className="text-sm font-bold text-brand-text-secondary mb-3">الحالة المالية</div>
               <div className={`flex items-center gap-2 px-5 py-2.5 rounded-full border ${getStatusColor(receipt.status)} shadow-lg`}>
                 {getStatusIcon(receipt.status)}
                 <span className="font-extrabold text-sm tracking-wide">{getStatusText(receipt.status)}</span>
               </div>
            </div>

            {/* Details Section */}
            <div className="space-y-4 relative">
              <div className="absolute -right-2 top-0 bottom-0 w-[1px] bg-gradient-to-b from-brand-blue/30 to-transparent"></div>
              
              <div className="flex gap-4 p-4 hover:bg-brand-bg-primary/30 rounded-2xl transition-colors">
                <div className="w-10 h-10 rounded-xl bg-brand-bg-primary border border-brand-border flex items-center justify-center shrink-0">
                  <FileText className="text-brand-blue" size={18} />
                </div>
                <div>
                  <div className="text-xs text-brand-text-secondary font-bold mb-1">رقم الفاتورة</div>
                  <div className="font-mono text-sm font-bold text-white tracking-wider">{receipt.id}</div>
                </div>
              </div>

              <div className="flex gap-4 p-4 hover:bg-brand-bg-primary/30 rounded-2xl transition-colors">
                <div className="w-10 h-10 rounded-xl bg-brand-bg-primary border border-brand-border flex items-center justify-center shrink-0">
                  <Briefcase className="text-emerald-500" size={18} />
                </div>
                <div>
                  <div className="text-xs text-brand-text-secondary font-bold mb-1">اسم المشروع</div>
                  <div className="text-sm font-bold text-white">{order.projectName}</div>
                </div>
              </div>

              <div className="flex gap-4 p-4 hover:bg-brand-bg-primary/30 rounded-2xl transition-colors">
                <div className="w-10 h-10 rounded-xl bg-brand-bg-primary border border-brand-border flex items-center justify-center shrink-0">
                  <User className="text-brand-orange" size={18} />
                </div>
                <div>
                  <div className="text-xs text-brand-text-secondary font-bold mb-1">اسم العميل المعتمد</div>
                  <div className="text-sm font-bold text-white">{order.customerName}</div>
                </div>
              </div>

              <div className="flex gap-4 p-4 hover:bg-brand-bg-primary/30 rounded-2xl transition-colors">
                <div className="w-10 h-10 rounded-xl bg-brand-bg-primary border border-brand-border flex items-center justify-center shrink-0">
                  <Calendar className="text-purple-500" size={18} />
                </div>
                <div>
                  <div className="text-xs text-brand-text-secondary font-bold mb-1">تاريخ الإنشاء والتوثيق</div>
                  <div className="text-sm font-bold text-white" dir="ltr">
                    {new Intl.DateTimeFormat('en-GB', { 
                        day: 'numeric', month: 'short', year: 'numeric', 
                        hour: 'numeric', minute: 'numeric', hour12: true 
                    }).format(receipt.createdAt)}
                  </div>
                </div>
              </div>

            </div>

             {/* Total Area */}
             <div className="mt-4 pt-6 border-t border-brand-border flex items-center justify-between">
                <div className="text-brand-text-secondary font-bold">المبلغ الإجمالي</div>
                <div className="text-2xl font-black text-brand-orange" dir="ltr">
                   {formatIraqiDinar(receipt.total)}
                </div>
             </div>

          </div>

          <div className="bg-[#0B0F19] p-4 text-center border-t border-brand-border/50">
             <Link to={`/receipt/${order.id}`}>
               <Button variant="outline" className="w-full text-xs font-bold bg-brand-bg-primary border-brand-border hover:bg-brand-blue hover:border-brand-blue hover:text-white transition-all duration-300 h-12">
                 عرض وصل الدفع الأصلي
               </Button>
             </Link>
          </div>
        </div>

        <div className="mt-8 text-center text-xs font-bold text-brand-text-secondary flex items-center justify-center gap-2">
           <CheckCircle2 size={14} className="text-emerald-500" />
           موثق ومشفر في قاعدة بيانات Codiar.Tech
        </div>
      </motion.div>
    </div>
  );
}
