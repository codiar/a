import { useEffect, useState, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import { doc, getDoc, collection, query, where, getDocs, setDoc, updateDoc } from "firebase/firestore";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";
import { useAuth } from "../hooks/useAuth";
import type { Order, Receipt as ReceiptType } from "../types";
import { motion } from "motion/react";
import { formatIraqiDinar } from "../lib/utils";
import { Button } from "../components/ui/Button";
import QRCode from "react-qr-code";
import { StatusStamp, CodiarCompanyStamp } from "../components/brand/Stamps";
import { CodiarLogo } from "../components/brand/CodiarLogo";
import { 
  FileText, 
  MessageCircle, 
  ShieldCheck, 
  Phone, 
  User, 
  Briefcase, 
  Layers, 
  Clock, 
  Calendar, 
  CreditCard, 
  Info, 
  Award,
  Download,
  HelpCircle,
  TrendingDown
} from "lucide-react";
// @ts-ignore
import { toJpeg } from "html-to-image";

const PRODUCTION_URL = "https://ais-pre-fwflbzrhdo74kyrriph7ic-914508587929.europe-west2.run.app";

const generateShortIdHex = (length: number) => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = '';
  for (const _ of Array(length)) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

export default function ReceiptPage() {
  const { id } = useParams<{id: string}>();
  const { user, isAdmin, loading: authLoading } = useAuth();
  const [receipt, setReceipt] = useState<ReceiptType | null>(null);
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [backfilling, setBackfilling] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (authLoading) return;
    if (id) {
      const fetchReceipt = async () => {
        try {
          let rData: ReceiptType | null = null;
          let oData: Order | null = null;

          // 1. Check if ID is a project ID
          const projectSnap = await getDoc(doc(db, "projects", id));
          if (projectSnap.exists()) {
             const pData = projectSnap.data();
             let projReceiptId = pData.receiptId;
             let projOrderId = pData.orderId;

             if (projReceiptId) {
                const targetReceiptSnap = await getDoc(doc(db, "receipts", projReceiptId));
                if (targetReceiptSnap.exists()) {
                   rData = targetReceiptSnap.data() as ReceiptType;
                }
             }
             if (projOrderId) {
                const targetOrderSnap = await getDoc(doc(db, "orders", projOrderId));
                if (targetOrderSnap.exists()) {
                   oData = targetOrderSnap.data() as Order;
                }
             }

             // BACKFILL LOGIC: If a legacy/old project is missing its linked Order/Receipt docs in Firestore, auto-create them!
             if (!rData || !oData) {
                setBackfilling(true);
                const newOrExistingOrderId = projOrderId || 'ORD-' + generateShortIdHex(7);
                const newOrExistingReceiptId = projReceiptId || 'INV-' + generateShortIdHex(6);

                let clientName = "عميل كوديار المعتمد";
                let clientPhone = "+9647800000000";
                
                try {
                  const clientSnap = await getDoc(doc(db, "users", pData.clientId));
                  if (clientSnap.exists()) {
                     const uData = clientSnap.data();
                     clientName = uData.name || clientName;
                     clientPhone = uData.phone || clientPhone;
                  }
                } catch (err) {
                  console.error("Failed to query user details for legacy backfill:", err);
                }

                // Compute logical price levels based on package
                let months = 12;
                let pricePerMonth = 19000;
                if (pData.package?.includes("الذهبية")) pricePerMonth = 19000;
                else if (pData.package?.includes("الاحترافية")) pricePerMonth = 39000;
                else if (pData.package?.includes("الفاخرة")) pricePerMonth = 79000;
                else if (pData.package?.includes("الدعم")) pricePerMonth = 0;

                const baseTotal = pricePerMonth * months;
                const discountVal = pricePerMonth > 0 ? Math.round(baseTotal * 0.25) : 0; // 25% discount for annual
                const finalTotal = baseTotal - discountVal;

                if (!oData) {
                   oData = {
                      id: newOrExistingOrderId,
                      clientId: pData.clientId,
                      customerName: clientName,
                      phone: clientPhone,
                      projectName: pData.name,
                      category: pData.type || "مواقع كوديار والمنيو",
                      package: pData.package || "الباقة الذهبية (Gold)",
                      duration: "12 شهر (خصم 25%)",
                      paymentMethod: "Zain Cash",
                      status: pData.status === 'active' ? 'paid' : (pData.status === 'cancelled' ? 'cancelled' : 'unpaid'),
                      total: finalTotal,
                      createdAt: pData.createdAt || Date.now(),
                      updatedAt: Date.now(),
                      projectId: pData.id,
                      receiptId: newOrExistingReceiptId
                   };
                   await setDoc(doc(db, "orders", newOrExistingOrderId), oData);
                }

                if (!rData) {
                   rData = {
                      id: newOrExistingReceiptId,
                      orderId: newOrExistingOrderId,
                      clientId: pData.clientId,
                      status: pData.status === 'active' ? 'paid' : (pData.status === 'cancelled' ? 'cancelled' : 'unpaid'),
                      total: finalTotal,
                      createdAt: pData.createdAt || Date.now(),
                      projectId: pData.id
                   };
                   await setDoc(doc(db, "receipts", newOrExistingReceiptId), rData);
                }

                // Attach references back inside legacy project permanently to resolve BUG #1
                await updateDoc(doc(db, "projects", pData.id), {
                   orderId: newOrExistingOrderId,
                   receiptId: newOrExistingReceiptId,
                   updatedAt: Date.now()
                }).catch(e => console.error("Error writing legacy references to project doc:", e));
                
                setBackfilling(false);
             }
          }

          // 2. Fetch by Order ID directly if not resolved
          if (!oData) {
            const orderCheckSnap = await getDoc(doc(db, "orders", id));
            if (orderCheckSnap.exists()) {
                oData = orderCheckSnap.data() as Order;
                
                // Fetch receipt corresponding to order
                const q = query(collection(db, "receipts"), where("orderId", "==", id));
                const querySnapshot = await getDocs(q);
                if (!querySnapshot.empty) {
                   rData = querySnapshot.docs[0].data() as ReceiptType;
                }
                
                if (!rData) {
                   const receiptSnap = await getDoc(doc(db, "receipts", id));
                   if (receiptSnap.exists()) {
                      rData = receiptSnap.data() as ReceiptType;
                   } else {
                      rData = {
                         id: oData.receiptId || id,
                         orderId: oData.id,
                         clientId: oData.clientId,
                         status: oData.status,
                         statusList: oData.statusList || [oData.status],
                         total: oData.total,
                         createdAt: oData.createdAt || Date.now(),
                         projectId: oData.projectId || id
                      };
                      await setDoc(doc(db, "receipts", rData.id), rData).catch(e => console.error("Self-healing receipts failed:", e));
                   }
                }
            }
          }

          // 3. Fallback: Query by Receipt ID directly
          if (!rData) {
             const receiptSnap = await getDoc(doc(db, "receipts", id));
             if (receiptSnap.exists()) {
                rData = receiptSnap.data() as ReceiptType;
             }
          }

          // Secure order bind
          if (rData) {
             setReceipt(rData);
             if (!oData) {
                const orderSnap = await getDoc(doc(db, "orders", rData.orderId));
                if (orderSnap.exists()) {
                   oData = orderSnap.data() as Order;
                } else {
                   oData = {
                      id: rData.orderId || id,
                      clientId: rData.clientId,
                      customerName: "عميل كوديار المعتمد",
                      phone: "+9647800000000",
                      projectName: "مشروع كوديار الرقمي",
                      category: "مواقع كوديار والمنيو",
                      package: "الباقة الذهبية (Gold)",
                      duration: "12 شهر (خصم 25%)",
                      paymentMethod: "زين كاش",
                      status: rData.status as any,
                      statusList: rData.statusList || [rData.status],
                      total: rData.total,
                      createdAt: rData.createdAt || Date.now(),
                      updatedAt: Date.now(),
                      projectId: rData.projectId || id
                   };
                   await setDoc(doc(db, "orders", oData.id), oData).catch(e => console.error("Self-healing orders failed:", e));
                }
             }
             if (oData) setOrder(oData);
          }
        } catch (err) {
          handleFirestoreError(err, OperationType.GET, `receipts-load`);
        } finally {
          setLoading(false);
        }
      };
      fetchReceipt();
    }
  }, [id, authLoading]);

  if (authLoading || loading || backfilling) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-brand-text-secondary bg-[#0B0F19] gap-4">
        <div className="w-12 h-12 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
        <p className="font-bold text-lg select-none">جاري استخراج ومزامنة الفاتورة...</p>
      </div>
    );
  }

  if (!receipt || !order) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-red-500 bg-[#0B0F19] p-4 text-center">
        <div className="w-16 h-16 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mb-4 text-3xl font-extrabold">!</div>
        <h2 className="text-2xl font-extrabold mb-2">الفاتورة غير موجودة</h2>
        <p className="text-brand-text-secondary mb-6 font-medium">الرجاء التحقق من الرابط أو طلب الفاتورة مجدداً من الدعم الفني.</p>
        <Link to="/">
          <Button variant="outline" className="border-brand-border text-brand-text-primary hover:bg-brand-bg-primary">العودة للرئيسية</Button>
        </Link>
      </div>
    );
  }

  // Generate perfect custom WhatsApp payment link matching BUG #15
  const whatsappMsg = `مرحباً كوديار تك، أود تأكيد سداد الفاتورة للخدمة البرمجية:
- رقم الطلب: ${order.id}
- رقم الفاتورة: ${receipt.id}
- اسم المشروع: ${order.projectName}
- الحزمة: ${order.package}
- السعر: ${order.total.toLocaleString()} د.ع
- طريقة الدفع: ${order.paymentMethod}`;
  
  const whatsappPaymentUrl = `https://wa.me/9647892966486?text=${encodeURIComponent(whatsappMsg)}`;
  const whatsappSupportUrl = `https://wa.me/9647892966486?text=${encodeURIComponent(`مرحباً كوديار تك، لدي استفسار بخصوص الفاتورة رقم ${receipt.id}`)}`;

  // Permanent verification URL parsed for QR matching BUG #4
  const qrCodeUrl = `${window.location.origin}/verify/${receipt.id}`;

  const downloadPDF = async () => {
    const element = printRef.current;
    if (!element) return;

    // Temporarily patch CSSStyleSheet to prevent cross-origin cssRules access errors
    const originalCssRules = Object.getOwnPropertyDescriptor(CSSStyleSheet.prototype, 'cssRules');
    Object.defineProperty(CSSStyleSheet.prototype, 'cssRules', {
      get() {
        try {
          return originalCssRules?.get?.call(this);
        } catch (e) {
          return [];
        }
      },
      configurable: true
    });

    try {
      const dataUrl = await toJpeg(element, {
        quality: 1,
        backgroundColor: '#0B0F19',
        cacheBust: true,
        pixelRatio: 3,
        style: {
          transform: 'scale(1)',
          transformOrigin: 'top left',
          margin: '0',
        }
      });
      const link = document.createElement('a');
      link.download = `Codiar_Invoice_${receipt.id}.jpeg`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error("Image generation failed:", err);
      window.print();
    } finally {
      if (originalCssRules) {
        Object.defineProperty(CSSStyleSheet.prototype, 'cssRules', originalCssRules);
      }
    }
  };

  // Human date formatting helper (Arabic)
  const formatDateArabic = (timestamp: number) => {
     return new Date(timestamp).toLocaleDateString('ar-IQ', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
     });
  };

  // Base price computations
  let basePrice = order.total;
  if (order.duration.includes("12")) {
     basePrice = Math.round(order.total / 0.75); // reverse map 25% discount 
  } else if (order.duration.includes("6")) {
     basePrice = Math.round(order.total / 0.90); // 10%
  } else if (order.duration.includes("3")) {
     basePrice = Math.round(order.total / 0.95); // 5%
  }
  const discountAmount = basePrice - order.total;

  return (
    <div className="max-w-4xl mx-auto py-16 px-4 sm:px-6">
      
      {/* Action panel */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6 bg-brand-bg-secondary p-6 rounded-3xl border border-brand-border">
         <div>
            <h1 className="text-2xl font-extrabold text-brand-text-primary tracking-tight">الفاتورة الضريبية الرسمية</h1>
            <p className="text-brand-text-secondary text-sm font-medium mt-1">تنزيل الفاتورة بصيغة PDF وتأكيد السداد عبر القنوات الرسمية.</p>
         </div>
         <div className="flex flex-wrap gap-3 w-full md:w-auto">
            <Button 
              variant="outline" 
              onClick={downloadPDF}
              className="flex-1 md:flex-none bg-brand-bg-primary text-brand-text-primary hover:bg-brand-bg-secondary border-brand-border shadow-sm h-11 px-5"
            >
              <Download size={16} className="ml-2 text-brand-orange" />
              تنزيل الفاتورة
            </Button>
            <a href={whatsappPaymentUrl} target="_blank" rel="noreferrer" className="flex-1 md:flex-none">
              <Button className="w-full bg-[#10B981] hover:bg-[#059669] border-none text-white font-bold h-11 px-5 shadow-lg shadow-emerald-500/10">
                <MessageCircle size={16} className="ml-2" />
                الدفع عبر واتساب
              </Button>
            </a>
            <a href={whatsappSupportUrl} target="_blank" rel="noreferrer" className="flex-1 md:flex-none">
              <Button variant="outline" className="w-full border-brand-border hover:bg-brand-bg-primary text-brand-text-secondary h-11 px-4">
                 التواصل مع الإدارة
              </Button>
            </a>
         </div>
      </div>

      {/* Main Print Container for PDF/Canvas */}
      <motion.div 
        id="printRef"
        ref={printRef}
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-[#0B0F19] text-white rounded-3xl shadow-2xl overflow-hidden relative border border-[#1E293B] pb-10"
      >
        {/* HUGE LUXURY CODIAR SHIELD WATERMARK behind invoice matching BUG #10 */}
        <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none z-0 overflow-hidden">
          <svg viewBox="0 0 100 100" className="w-[120%] h-[120%] stroke-white fill-none" strokeWidth="2">
            <path d="M50 8 L88 28 L88 68 L50 92 L12 68 L12 28 Z" />
            <path d="M40 36 L26 50 L40 64" />
            <path d="M60 36 L74 50 L60 64" />
            <path d="M47 32 L53 68" />
          </svg>
        </div>

        {/* Invoice Top Ribbon Header with elegant corporate style */}
        <div className="bg-[#111827] p-10 relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center border-b border-[#1E293B] gap-6">
            <div className="flex items-center gap-5">
              {/* Codiar Vector Icon */}
              <div className="w-16 h-16 bg-[#0B0F19] rounded-2xl flex items-center justify-center border border-[#1E293B] shadow-lg shrink-0">
                <svg width="40" height="40" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M50 10 L85 30 L85 70 L50 90 L15 70 L15 30 Z" stroke="#3b82f6" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" fill="#0B0F19" />
                  <path d="M42 38 L28 50 L42 62" stroke="#3b82f6" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M58 38 L72 50 L58 62" stroke="#F97316" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M47 34 L53 66" stroke="#3b82f6" strokeWidth="6" strokeLinecap="round" />
                </svg>
              </div>
              <div>
                <h2 className="text-3xl font-black tracking-tight text-white flex items-center gap-2">
                  كوديار <span className="text-[#3b82f6]">تك</span>
                </h2>
                <p className="text-xs text-slate-400 font-bold tracking-widest uppercase mt-1">الريادة البرمجية والحلول الرقمية الفاخرة</p>
              </div>
            </div>
            
            <div className="flex flex-col items-start md:items-end">
               <span className="text-[10px] text-slate-500 font-bold tracking-widest uppercase mb-1">المستند المالي الموثق</span>
               <div className="bg-[#0B0F19] px-5 py-2.5 rounded-xl border border-[#1E293B] font-mono text-xl font-bold tracking-tight text-slate-100 flex items-center gap-2">
                 <span className="text-[#F97316] text-xs font-sans font-extrabold pr-2 border-r border-[#1E293B]">رقم الفاتورة</span>
                 <span>{receipt.id}</span>
               </div>
            </div>
        </div>

        {/* Verification Status Ribbon matching BUG #4 */}
        <div className="bg-gradient-to-r from-[#1E293B]/65 to-[#0F172A]/85 px-10 py-4 border-b border-[#1E293B] flex items-center gap-3 text-emerald-400 font-bold relative z-10 text-xs">
           <ShieldCheck size={16} className="text-emerald-400 shrink-0" />
           <span>فاتورة آمنة وموثقة برمجياً في خواديم كوديار الرسمية</span>
           <span className="mr-auto bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-full border border-emerald-500/20 text-[10px] font-extrabold tracking-wide uppercase">
             مضمون ✓
           </span>
        </div>

        {/* Inner Content Area */}
        <div className="p-10 md:p-14 relative z-10">
          
          {/* Stamps & Top metadata */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-14">
             <div className="font-mono text-xs text-slate-400 space-y-2.5">
                <div className="flex items-center gap-3">
                   <Calendar size={14} className="text-slate-500" />
                   <span className="text-slate-500 uppercase tracking-wider font-semibold w-24">تاريخ الفاتورة:</span>
                   <span className="text-white font-bold">{formatDateArabic(order.createdAt)}</span>
                </div>
                <div className="flex items-center gap-3">
                   <Clock size={14} className="text-slate-500" />
                   <span className="text-slate-500 uppercase tracking-wider font-semibold w-24">المرجع:</span>
                   <span className="text-white font-bold">{order.id}</span>
                </div>
                <div className="flex items-center gap-3">
                   <Award size={14} className="text-slate-500" />
                   <span className="text-slate-500 uppercase tracking-wider font-semibold w-24">رمز الهوية:</span>
                   <span className="text-white font-semibold font-mono text-[10px] bg-slate-800/50 px-2 py-0.5 rounded border border-slate-700/40">PRJ-{order.projectId || id}</span>
                </div>
             </div>

             {/* Double Official Stamps side-by-side matching BUG #11 & #12 */}
             <div className="flex items-center gap-4">
                <StatusStamp status={receipt.status} date={new Date(receipt.createdAt).toLocaleDateString('en-GB')} />
                <CodiarCompanyStamp />
             </div>
          </div>

          {/* Client & Project Details Grid - 2 Column Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
             <div className="bg-[#111827]/40 border border-[#1E293B] p-6 rounded-2xl flex flex-col justify-between">
                <div>
                   <h3 className="text-[10px] uppercase tracking-widest text-[#F97316] font-extrabold mb-4 flex items-center gap-2">
                     <div className="w-1.5 h-1.5 rounded-full bg-[#F97316]"></div> 
                     بيانات المستفيد والعميل
                   </h3>
                   <div className="space-y-3 font-semibold">
                      <div className="flex items-center gap-2.5">
                         <User size={16} className="text-slate-500 shrink-0" />
                         <span className="text-slate-400 text-xs w-20">الاسم الكامل:</span>
                         <span className="text-slate-100 text-sm font-bold">{order.customerName}</span>
                      </div>
                      <div className="flex items-center gap-2.5">
                         <Phone size={16} className="text-slate-500 shrink-0" />
                         <span className="text-slate-400 text-xs w-20">رقم الهاتف:</span>
                         <span className="text-slate-100 text-sm font-mono tracking-wider" dir="ltr">{order.phone || "لا يوجد"}</span>
                      </div>
                   </div>
                </div>
                <div className="text-[10px] text-slate-500 font-medium italic mt-6 border-t border-[#1E293B]/40 pt-3">
                   معتمد كشريك استراتيجي لدى شركة كوديار تك.
                </div>
             </div>

             <div className="bg-[#111827]/40 border border-[#1E293B] p-6 rounded-2xl flex flex-col justify-between">
                <div>
                   <h3 className="text-[10px] uppercase tracking-widest text-[#3b82f6] font-extrabold mb-4 flex items-center gap-2">
                     <div className="w-1.5 h-1.5 rounded-full bg-[#3b82f6]"></div> 
                     تفاصيل وبيانات المشروع
                   </h3>
                   <div className="space-y-3 font-semibold">
                      <div className="flex items-center gap-2.5">
                         <Briefcase size={16} className="text-slate-500 shrink-0" />
                         <span className="text-slate-400 text-xs w-20">اسم المشروع:</span>
                         <span className="text-[#3b82f6] text-sm font-black">{order.projectName}</span>
                      </div>
                      <div className="flex items-center gap-2.5">
                         <Layers size={16} className="text-slate-500 shrink-0" />
                         <span className="text-slate-400 text-xs w-20">فئة المشروع:</span>
                         <span className="text-slate-100 text-sm">{order.category}</span>
                      </div>
                   </div>
                </div>
                {order.description && (
                   <div className="text-xs text-slate-400 mt-5 border-t border-[#1E293B]/40 pt-3 flex gap-2">
                     <Info size={14} className="text-[#F97316] shrink-0 mt-0.5" />
                     <p className="leading-relaxed shrink">{order.description}</p>
                   </div>
                )}
             </div>
          </div>

          {/* Pricing Ledger Card */}
          <div className="bg-[#111827]/35 border border-[#1E293B] rounded-2xl p-6 md:p-8 mb-12">
            <h3 className="text-sm font-bold text-slate-200 mb-6 pb-2 border-b border-[#1E293B] flex items-center gap-2">
              <CreditCard size={16} className="text-[#3b82f6]" />
              جدول المحاسبة والرسوم المالية للمشروع
            </h3>

            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm font-semibold text-slate-300">
                <div className="flex flex-col">
                  <span className="text-white text-base font-bold">{order.package}</span>
                  <span className="text-slate-500 text-xs mt-1">تفعيل الاستضافة المتكاملة والربط الرقمي للدومين</span>
                </div>
                <div className="text-slate-400 font-medium font-mono text-xs">{order.duration}</div>
                <div className="text-white font-bold font-mono text-base" dir="ltr">
                  {basePrice > 0 ? formatIraqiDinar(basePrice) : "0 د.ع"}
                </div>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between items-center text-xs font-bold text-emerald-400 bg-emerald-500/5 py-3 px-4 rounded-xl border border-emerald-500/10">
                  <span className="flex items-center gap-2">
                    <TrendingDown size={14} />
                    خصم باقة التجديد والاستثمار المطول الخاص بكوديار
                  </span>
                  <span className="font-mono" dir="ltr">-{formatIraqiDinar(discountAmount)}</span>
                </div>
              )}

              <div className="pt-6 border-t border-[#1E293B] flex justify-between items-center">
                 <div className="flex flex-col">
                    <span className="text-slate-400 text-xs font-extrabold uppercase tracking-wider mb-1">المجموع الكلي للاستثمار</span>
                    <span className="text-[10px] text-slate-500 font-semibold bg-[#0B0F19] px-2.5 py-1 rounded border border-[#1E293B] inline-block mt-1">
                      طريقة الدفع: <span className="text-[#F97316] font-bold">{order.paymentMethod}</span>
                    </span>
                 </div>
                 <div className="text-3xl font-black font-mono text-[#F97316]" dir="ltr">
                   {formatIraqiDinar(order.total)}
                 </div>
              </div>
            </div>
          </div>

          {/* Footer Validation and Dynamic QR Code matching BUG #4 */}
          <div className="flex flex-col md:flex-row justify-between items-end gap-10 border-t border-dashed border-[#1E293B] pt-10">
             <div className="space-y-3 text-slate-400 font-semibold text-xs leading-relaxed max-w-md">
                <p className="flex items-center gap-2 text-white text-sm font-extrabold">
                  <ShieldCheck size={16} className="text-[#3b82f6]" />
                  شروط المصداقية وسياسة الضمان
                </p>
                <p>• هذه الفاتورة رسمية تصدر تلقائياً عن النظام السحابي لشركة كوديار تك كتوثيق للمشاريع والرسوم.</p>
                <p>• الفاتورة آمنة تماماً ومحمية برمجياً. يمكن لأي طرف فحص مطابقة الفاتورة على خادم كوديار من خلال مسح رمز QR المرفق بجانب المستند.</p>
                <p>• يُرجى حفظ هذه الفاتورة وإبرازها كمرجع مالي معتمد عند تعاملات الدعم الفني وتجديد الإيجار الرقمي للهوية.</p>
             </div>

             {/* QR Verification Frame */}
             <div className="flex items-center gap-5 bg-[#111827] p-5 rounded-2xl border border-[#1E293B] shadow-xl relative overflow-hidden shrink-0">
                <div className="text-right">
                  <h4 className="text-white text-sm font-bold mb-1">بوابة التحقق</h4>
                  <p className="text-[9px] text-slate-500 font-extrabold uppercase tracking-widest leading-relaxed">
                     امسح الرمز ضوئياً<br/>لمطابقة البيانات
                  </p>
                </div>
                <div className="p-2.5 bg-white rounded-xl shadow-inner relative flex items-center justify-center">
                   <QRCode value={qrCodeUrl} size={92} level="H" />
                </div>
             </div>
          </div>

        </div>
      </motion.div>
    </div>
  );
}
