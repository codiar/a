import { motion } from "motion/react";
import { Shield } from "lucide-react";

export default function Privacy() {
  return (
    <div className="py-24 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-16 text-center"
      >
        <div className="w-20 h-20 bg-brand-bg-secondary rounded-2xl flex items-center justify-center mx-auto mb-6 border border-brand-border shadow-sm">
          <Shield size={36} className="text-brand-text-primary" />
        </div>
        <h1 className="text-4xl font-black text-brand-text-primary mb-4 tracking-tight">سياسة الخصوصية</h1>
        <p className="text-brand-text-secondary font-medium">آخر تحديث: 1 أكتوبر 2024</p>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-brand-bg-secondary border border-brand-border rounded-[2.5rem] p-8 md:p-12 prose prose-invert max-w-none text-brand-text-secondary leading-relaxed"
      >
        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">1. مقدمة</h2>
        <p className="mb-8 font-medium">
          مرحباً بكم في منصة كوديار تك (Codiar Tech). نحن نأخذ خصوصيتك وحماية بياناتك الشخصية على محمل الجد. تشرح سياسة الخصوصية هذه كيف نقوم بجمع معلوماتك واستخدامها وحمايتها عند استخدام موقعنا وخدماتنا.
        </p>

        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">2. المعلومات التي نجمعها</h2>
        <ul className="list-disc pr-6 mb-8 font-medium space-y-2">
          <li>المعلومات الشخصية التي تقدمها طواعية (الاسم، البريد الإلكتروني، رقم الهاتف).</li>
          <li>معلومات تفاصيل المشروع والملفات المرفقة لغرض دراسة المتطلبات.</li>
          <li>بيانات الاستخدام وملفات تعريف الارتباط (Cookies) لتحسين تجربة تصفحك.</li>
        </ul>

        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">3. كيف نستخدم معلوماتك؟</h2>
        <ul className="list-disc pr-6 mb-8 font-medium space-y-2">
          <li>توفير الخدمات وإدارة حسابك والرد على استفساراتك.</li>
          <li>تحسين جودة منصتنا وخدماتنا بناءً على الملاحظات.</li>
          <li>التواصل معك بشأن تحديثات المشروع أو العروض الخاصة.</li>
        </ul>

        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">4. حماية البيانات</h2>
        <p className="mb-8 font-medium">
          نحن نستخدم إجراءات أمنية تقنية عالية (مثل تشفير قواعد البيانات والاتصال الآمن HTTPS) لحماية بياناتك من الوصول غير المصرح به أو التعديل أو الكشف أو التدمير. لا نقوم مطلقاً ببيع بياناتك لأطراف خارجية.
        </p>

        <h2 className="text-2xl font-bold text-brand-text-primary mb-4">5. التغييرات على هذه السياسة</h2>
        <p className="font-medium">
          نحتفظ بالحق في تحديث سياسة الخصوصية هذه في أي وقت. سيتم إشعار المستخدمين بأي تغييرات جوهرية عن طريق تحديث تاريخ "آخر تحديث" في أعلى هذه الصفحة.
        </p>
      </motion.div>
    </div>
  )
}
