import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { db, handleFirestoreError, OperationType } from "../lib/firebase";
import { collection, query, getDocs, updateDoc, doc, where, getDoc, deleteDoc } from "firebase/firestore";
import type { Order, Project, Review } from "../types";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "../components/ui/Button";
import { motion, AnimatePresence } from "motion/react";
import QRCode from "react-qr-code";
import { formatIraqiDinar } from "../lib/utils";
import { 
  LayoutDashboard, 
  CreditCard, 
  Activity, 
  ArrowUpRight, 
  CheckCircle2, 
  Clock, 
  Globe, 
  Users, 
  Briefcase, 
  TrendingUp, 
  Calendar, 
  Sliders, 
  FileText, 
  Eye, 
  Sparkles, 
  AlertCircle, 
  DollarSign, 
  Check, 
  HelpCircle,
  Hash,
  ScanQrCode,
  X,
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  Trash2
} from "lucide-react";

export default function AdminDashboard() {
  const { user, dbUser, loading, isAdmin } = useAuth();
  const navigate = useNavigate();
  
  const [orders, setOrders] = useState<Order[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [fetching, setFetching] = useState(true);
  
  // Tab indicators
  const [invoiceTab, setInvoiceTab] = useState<"active" | "inactive">("active");
  const [projectTab, setProjectTab] = useState<"ongoing" | "archived">("ongoing");
  const [showQrForInvoice, setShowQrForInvoice] = useState<string | null>(null);

  // Discount Modal State
  const [discountModalOrder, setDiscountModalOrder] = useState<Order | null>(null);
  const [adminNotes, setAdminNotes] = useState("");

  const PRODUCTION_URL = "https://ais-pre-fwflbzrhdo74kyrriph7ic-914508587929.europe-west2.run.app";
  
  // Custom states for completing a project (requires URL)
  const [completingProject, setCompletingProject] = useState<string | null>(null);
  const [completionUrl, setCompletionUrl] = useState("");
  
  // Notification feeds
  const [systemLogs, setSystemLogs] = useState<string[]>([
    "نظام الفواتير الموحد يعمل بكفاءة 100%",
    "خوادم كوديار السحابية في بغداد والشرق الأوسط نشطة",
    "بوابة التحقق السريع من رمز QR آمنة ومفعلة"
  ]);

  // Toast status notifier
  const [toast, setToast] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 4000);
  };

  useEffect(() => {
    if (!loading && (!user || !isAdmin)) {
      navigate("/");
    }
  }, [user, loading, isAdmin, navigate]);

  const fetchData = async () => {
    if (isAdmin) {
      try {
        const qOrders = query(collection(db, "orders"));
        const snapOrders = await getDocs(qOrders);
        setOrders(snapOrders.docs.map(d => d.data() as Order).sort((a,b) => b.createdAt - a.createdAt));

        const qProjects = query(collection(db, "projects"));
        const snapProjects = await getDocs(qProjects);
        setProjects(snapProjects.docs.map(d => d.data() as Project).sort((a,b) => b.createdAt - a.createdAt));

        const qReviews = query(collection(db, "reviews"));
        const snapReviews = await getDocs(qReviews);
        setReviews(snapReviews.docs.map(d => ({id: d.id, ...d.data()} as Review)).sort((a,b) => b.createdAt - a.createdAt));
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, 'admin-dashboard-data');
      } finally {
        setFetching(false);
      }
    }
  };

  useEffect(() => {
    fetchData();
  }, [isAdmin]);

  // Status updates handlers
  const openDiscountModal = (order: Order) => {
    setDiscountModalOrder(order);
    setAdminNotes(order.adminNotes || "");
  };

  const handleDiscountApproval = async (status: string) => {
    if (!discountModalOrder) return;
    try {
      await updateDoc(doc(db, "orders", discountModalOrder.id), {
        status: status,
        statusList: [...(discountModalOrder.statusList || []), status],
        adminNotes: adminNotes,
        updatedAt: Date.now()
      });
      // also update receipt
      if (discountModalOrder.receiptId) {
        await updateDoc(doc(db, "receipts", discountModalOrder.receiptId), {
           status: status,
           statusList: [...(discountModalOrder.statusList || []), status],
           updatedAt: Date.now()
        });
      }
      showToast(status === "paid" ? "تم قبول طلب الخصم بنجاح." : "تم رفض طلب الخصم.");
      setDiscountModalOrder(null);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${discountModalOrder.id}`);
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, "orders", orderId), { 
        status: newStatus,
        statusList: [newStatus],
        updatedAt: Date.now() 
      });
      
      // Sync to corresponding receipts
      const q = query(collection(db, "receipts"), where("orderId", "==", orderId));
      const snap = await getDocs(q);
      if (!snap.empty) {
         await updateDoc(doc(db, "receipts", snap.docs[0].id), { 
           status: newStatus,
           statusList: [newStatus]
         });
      }
      
      showToast(`تم تحديث حالة الطلب ${orderId} بنجاح.`);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `orders/${orderId}`);
    }
  };

  const updateProjectStatus = async (projectId: string, newStatus: string) => {
    try {
      if (newStatus === "completed" || newStatus === "active") {
        // completion prompt triggering
        const proj = projects.find(p => p.id === projectId);
        if (proj && !proj.url) {
          setCompletingProject(projectId);
          setCompletionUrl("");
          return;
        }
      }

      await updateDoc(doc(db, "projects", projectId), { 
        status: newStatus,
        statusList: [newStatus],
        updatedAt: Date.now() 
      });
      showToast(`تم تحديث حالة المشروع بنجاح.`);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `projects/${projectId}`);
    }
  };

  // Saved Completed Project with required URL
  const saveCompletedProjectState = async () => {
    if (!completingProject) return;
    if (!completionUrl.trim()) {
      showToast("يرجى إدخال رابط الموقع الإلكتروني أولاً.");
      return;
    }
    
    let cleanUrl = completionUrl.trim();
    if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
      cleanUrl = "https://" + cleanUrl;
    }

    try {
      await updateDoc(doc(db, "projects", completingProject), {
        status: "active",
        statusList: ["active", "completed"],
        url: cleanUrl,
        updatedAt: Date.now()
      });
      
      showToast(`تم تفعيل المشروع وإدخال رابط الدومين بنجاح!`);
      setCompletingProject(null);
      setCompletionUrl("");
      fetchData();
    } catch (err) {
      showToast("فشل تحديث بيانات إكمال المشروع.");
    }
  };

  const updateProjectUrlDirectly = async (projectId: string, newUrl: string) => {
    if (!newUrl.trim()) return;
    let cleanUrl = newUrl.trim();
    if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
      cleanUrl = "https://" + cleanUrl;
    }
    try {
      await updateDoc(doc(db, "projects", projectId), { url: cleanUrl, updatedAt: Date.now() });
      showToast("تم تحديث رابط الدومين بنجاح.");
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `projects/${projectId}`);
    }
  };

  const hardDeleteProject = async (projectId: string) => {
    try {
      if (!confirm("هل أنت متأكد من حذف هذا المشروع نهائياً؟ لا يمكن التراجع عن هذا الإجراء.")) return;
      await deleteDoc(doc(db, "projects", projectId));
      showToast("تم حذف المشروع بنجاح.");
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `projects/${projectId}`);
    }
  };

  const updateReviewStatus = async (reviewId: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, "reviews", reviewId), { status: newStatus });
      showToast(`تم تحديث حالة التقييم بنجاح.`);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `reviews/${reviewId}`);
    }
  };

  const deleteReview = async (reviewId: string) => {
    try {
      if (!confirm("هل أنت متأكد من حذف هذا التقييم نهائياً؟")) return;
      await deleteDoc(doc(db, "reviews", reviewId));
      showToast(`تم حذف التقييم.`);
      fetchData();
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `reviews/${reviewId}`);
    }
  };

  if (loading || fetching) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-brand-text-secondary bg-[#0B0F19] gap-3">
        <div className="w-12 h-12 border-4 border-brand-orange border-t-transparent rounded-full animate-spin"></div>
        <p className="font-bold text-lg select-none">جاري تحميل لوحة التحكم الفنية والمحاسبية الموحدة...</p>
      </div>
    );
  }

  // --- STATS ENGINE calculations ---
  const activeProjectsList = projects.filter(p => p.status === 'active' || (p.statusList && p.statusList.includes('active')));
  const completedProjectsList = projects.filter(p => p.status === 'completed' || (p.statusList && p.statusList.includes('completed')));
  
  const totalRevenue = orders.filter(o => o.status === 'paid' || o.status === 'completed').reduce((acc, curr) => acc + curr.total, 0);
  const pendingPaymentsAmount = orders.filter(o => o.status === 'unpaid' || o.status === 'pending').reduce((acc, curr) => acc + curr.total, 0);
  const outstandingInvoicesCount = orders.filter(o => o.status === 'unpaid' || o.status === 'pending').length;

  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth(); // 0-based

  // Monthly Revenue
  const monthlyRevenueTotal = orders
    .filter(o => {
      if (o.status !== 'paid' && o.status !== 'completed') return false;
      const oDate = new Date(o.createdAt);
      return oDate.getFullYear() === currentYear && oDate.getMonth() === currentMonth;
    })
    .reduce((acc, curr) => acc + curr.total, 0);

  // Yearly Revenue
  const yearlyRevenueTotal = orders
    .filter(o => {
      if (o.status !== 'paid' && o.status !== 'completed') return false;
      const oDate = new Date(o.createdAt);
      return oDate.getFullYear() === currentYear;
    })
    .reduce((acc, curr) => acc + curr.total, 0);

  const upcomingRenewalsList = projects.filter(p => {
    if (!p.expirationDate) return false;
    const diffTime = p.expirationDate - Date.now();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 && diffDays <= 30; // expiring within 30 days
  });

  const uniqueClientsCount = Array.from(new Set(orders.map(o => o.clientId))).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Toast Alert Box */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 15 }}
            className="fixed bottom-8 left-8 z-50 bg-[#1e293b] text-emerald-300 border border-emerald-500/30 px-5 py-3 rounded-2xl shadow-2xl flex items-center gap-2 font-bold text-sm"
          >
            <CheckCircle2 size={16} className="text-emerald-400" />
            <span>{toast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* QR Code Verification Modal */}
      <AnimatePresence>
        {showQrForInvoice && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-brand-bg-secondary border border-brand-border rounded-3xl p-6 md:p-8 w-full max-w-sm shadow-2xl relative flex flex-col items-center text-center"
            >
              <button 
                onClick={() => setShowQrForInvoice(null)}
                className="absolute top-4 left-4 text-brand-text-secondary hover:text-white bg-brand-bg-primary hover:bg-red-500/10 p-2 rounded-full transition-colors"
              >
                <X size={18} />
              </button>
              
              <div className="w-14 h-14 bg-[#3b82f6]/10 text-brand-blue rounded-full flex items-center justify-center mb-5">
                <ScanQrCode size={28} />
              </div>
              
              <h3 className="text-xl font-black text-white mb-2">رمز التحقق للعميل</h3>
              <p className="text-brand-text-secondary text-xs font-semibold mb-6">
                يمكن للعميل مسح هذا الرمز لعرض مستند الدفع الخاص به وتوثيقه مباشر.
              </p>
              
              <div className="bg-white p-4 rounded-2xl shadow-xl w-full flex items-center justify-center">
                 <QRCode value={`${window.location.origin}/verify/${showQrForInvoice}`} size={200} level="Q" />
              </div>
              
              <div className="mt-6 text-xs text-slate-500 font-mono flex items-center gap-2 bg-[#0B0F19] px-4 py-2 rounded-xl border border-brand-border">
                <span className="text-brand-orange font-bold uppercase tracking-widest text-[9px]">ID:</span>
                {showQrForInvoice}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Completion Modal Prompt */}
      <AnimatePresence>
        {completingProject && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-brand-bg-secondary border border-brand-border rounded-3xl p-6 sm:p-8 w-full max-w-md shadow-2xl"
            >
              <div className="w-12 h-12 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mb-4">
                <Globe size={24} />
              </div>
              <h3 className="text-xl font-extrabold text-brand-text-primary mb-2">إكمال المشروع وتفعيل العنوان</h3>
              <p className="text-brand-text-secondary text-xs font-semibold leading-relaxed mb-6">
                لقد قمت بتحديد حالة المشروع بأنه "مكتمل/نشط". تتطلب هذه الخطوة إدخال الرابط الحقيقي للموقع الإلكتروني (Website URL) ليتمكن العميل من رؤيته مباشرة في لوحته الفنية.
              </p>
              
              <div className="space-y-4 mb-6">
                <div>
                  <label className="text-xs font-bold text-brand-text-secondary block mb-1.5">رابط الموقع (دومين العميل)</label>
                  <input 
                    type="text" 
                    value={completionUrl} 
                    onChange={(e) => setCompletionUrl(e.target.value)}
                    placeholder="example.com أو codiartech.com" 
                    className="w-full text-sm h-11 px-3 rounded-lg border border-brand-border bg-brand-bg-primary text-brand-text-primary outline-none focus:ring-1 focus:ring-brand-blue font-mono"
                  />
                </div>
              </div>

              <div className="flex gap-3">
                <Button onClick={saveCompletedProjectState} className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-bold h-11 rounded-lg">
                  حفظ وتفعيل كنشط
                </Button>
                <Button onClick={() => setCompletingProject(null)} variant="outline" className="flex-1 border-brand-border text-brand-text-secondary hover:bg-brand-bg-primary h-11 rounded-lg">
                  إلغاء
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Discount Approval Modal */}
      <AnimatePresence>
        {discountModalOrder && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-brand-bg-primary rounded-[2rem] p-8 max-w-md w-full shadow-2xl border border-brand-border"
            >
              <div className="flex justify-between items-center mb-6">
                 <h2 className="text-xl font-black text-brand-text-primary flex items-center gap-2">
                   مراجعة طلب الخصم
                 </h2>
                 <button onClick={() => setDiscountModalOrder(null)} className="p-2 hover:bg-brand-bg-secondary text-brand-text-secondary rounded-full border border-brand-border/40">
                   <X size={20} />
                 </button>
              </div>

              <div className="mb-4">
                 <label className="block text-sm font-bold text-brand-text-secondary mb-2">رابط دليل المشروع</label>
                 <div className="bg-brand-bg-secondary p-3 rounded-xl border border-brand-border flex items-center justify-between">
                    <span className="text-sm truncate mr-2" dir="ltr">{discountModalOrder.proofLink}</span>
                 </div>
              </div>

              <div className="mb-6">
                 <label className="block text-sm font-bold text-brand-text-secondary mb-2">ملاحظات وقرار الإدارة (اختياري)</label>
                 <textarea 
                   rows={3} 
                   value={adminNotes}
                   onChange={e => setAdminNotes(e.target.value)}
                   placeholder="اكتب ملاحظات حول القبول أو الرفض ليراها العميل..."
                   className="w-full bg-brand-bg-secondary border border-brand-border rounded-xl p-3 text-sm focus:ring-1 focus:ring-brand-orange outline-none resize-none"
                 />
              </div>

              <div className="flex items-center gap-3">
                 <Button onClick={() => handleDiscountApproval("paid")} className="flex-1 bg-green-600 hover:bg-green-700 text-white border-none py-4 font-bold">
                   قبول الخصم
                 </Button>
                 <Button onClick={() => handleDiscountApproval("cancelled")} className="flex-1 bg-red-600 hover:bg-red-700 text-white border-none py-4 font-bold">
                   رفض الخصم
                 </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Admin Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 bg-gradient-to-tr from-[#111827] to-[#020617] p-8 sm:p-10 rounded-3xl border border-brand-border">
        <div>
          <span className="text-[10px] text-brand-orange font-bold uppercase tracking-widest bg-brand-orange/10 px-2.5 py-1 rounded-full border border-brand-orange/20">منفذ التحكم الشامل</span>
          <h1 className="text-3xl sm:text-4xl font-black text-white mt-3 select-none">بوابة كوديار تك للإدارة الفنية</h1>
          <p className="text-brand-text-secondary text-sm font-semibold mt-1">إشراف دقيق على العمليات المحاسبية، وتكامل الفواتير الموحدة، ومتابعة تفعيل الدومينات.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button onClick={fetchData} className="bg-brand-text-primary text-brand-bg-primary hover:bg-brand-text-secondary font-bold text-sm h-11 px-5 rounded-xl">
            تحديث البيانات السحابية
          </Button>
        </div>
      </div>

      {/* SECTION 1: GENERAL OVERVIEW */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-brand-border">
          <LayoutDashboard className="text-[#3b82f6]" size={20} />
          <h2 className="text-xl font-bold text-brand-text-primary">1. الملخص والمؤشرات العامة</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
          <div className="bg-brand-bg-secondary p-5 rounded-2xl border border-brand-border">
            <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">إجمالي العملاء المميزين</span>
            <span className="text-3xl font-black text-brand-text-primary font-mono tracking-tight block mt-2">{uniqueClientsCount}</span>
          </div>
          <div className="bg-brand-bg-secondary p-5 rounded-2xl border border-brand-border">
            <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">إجمالي المشاريع الرقمية</span>
            <span className="text-3xl font-black text-brand-text-primary font-mono tracking-tight block mt-2">{projects.length}</span>
          </div>
          <div className="bg-brand-bg-secondary p-5 rounded-2xl border border-brand-border">
            <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">مشاريع مكتملة</span>
            <span className="text-3xl font-black text-emerald-400 font-mono tracking-tight block mt-2">{completedProjectsList.length}</span>
          </div>
          <div className="bg-brand-bg-secondary p-5 rounded-2xl border border-brand-border">
            <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">مشاريع غامرة نشطة</span>
            <span className="text-3xl font-black text-brand-blue font-mono tracking-tight block mt-2">{activeProjectsList.length}</span>
          </div>
          <div className="bg-brand-bg-secondary p-5 rounded-2xl border border-brand-border">
            <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">إجمالي التحصيلات (Revenue)</span>
            <span className="text-sm font-black text-emerald-500 font-mono tracking-tight block mt-2.5 truncate">{formatIraqiDinar(totalRevenue)}</span>
          </div>
          <div className="bg-brand-bg-secondary p-5 rounded-2xl border border-brand-border">
            <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-wider block">مدفوعات معلقة بالنظام</span>
            <span className="text-sm font-black text-brand-orange font-mono tracking-tight block mt-2.5 truncate">{formatIraqiDinar(pendingPaymentsAmount)}</span>
          </div>
        </div>
      </section>

      {/* SECTION 2: ACTIVE PROJECTS */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-brand-border">
          <Briefcase className="text-[#3b82f6]" size={20} />
          <h2 className="text-xl font-bold text-brand-text-primary">2. المشاريع الفعالة وإدارة الاتصال</h2>
        </div>

        <div className="bg-brand-bg-secondary rounded-3xl border border-brand-border overflow-hidden">
          <div className="flex border-b border-brand-border bg-brand-bg-secondary/45">
            <button 
              onClick={() => setProjectTab("ongoing")}
              className={`flex-1 py-4 text-sm font-extrabold transition-colors border-b-2 ${
                projectTab === "ongoing" ? "border-[#3b82f6] text-[#3b82f6] bg-[#0c101d]" : "border-transparent text-brand-text-secondary hover:text-brand-text-primary"
              }`}
            >
              المشاريع النشطة والجارية ({projects.filter(p => p.status !== "archived").length})
            </button>
            <button 
              onClick={() => setProjectTab("archived")}
              className={`flex-1 py-4 text-sm font-extrabold transition-colors border-b-2 ${
                projectTab === "archived" ? "border-[#3b82f6] text-[#3b82f6] bg-[#0c101d]" : "border-transparent text-brand-text-secondary hover:text-brand-text-primary"
              }`}
            >
              الأرشيف والمحذوفة ({projects.filter(p => p.status === "archived").length})
            </button>
          </div>
          <div className="p-6 border-b border-brand-border bg-brand-bg-secondary/45 flex justify-between items-center">
            <h3 className="text-base font-black text-brand-text-primary">متابعة نطاقات العملاء وتحديثات الهويات الرقمية المعتمدة</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead>
                <tr className="border-b border-brand-border text-xs font-bold text-brand-text-secondary uppercase select-none">
                  <th className="py-4 px-6">المشروع واجتهاد الخدمة</th>
                  <th className="py-4 px-6">أرقام التواصل</th>
                  <th className="py-4 px-6">رابط الويب (URL)</th>
                  <th className="py-4 px-6">تاريخ الصلاحية</th>
                  <th className="py-4 px-6">رابط الفاتورة</th>
                  <th className="py-4 px-6">الحالة</th>
                  <th className="py-4 px-6 text-left">التعديل</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-border/40 font-semibold text-brand-text-primary">
                {projects.filter(p => projectTab === 'archived' ? p.status === 'archived' : p.status !== 'archived').map(p => {
                  const correspondingOrder = orders.find(o => o.projectId === p.id || o.id === p.orderId);
                  const expiryDays = p.expirationDate ? Math.ceil((p.expirationDate - Date.now()) / (1000 * 60 * 60 * 24)) : 0;
                  
                  return (
                    <tr key={p.id} className="hover:bg-brand-bg-primary/40 transition-colors">
                      <td className="py-5 px-6">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg bg-[#3b82f6]/10 text-brand-blue flex items-center justify-center font-black">
                            {p.name?.charAt(0) || "P"}
                          </div>
                          <div>
                            <span className="font-extrabold text-sm block">{p.name}</span>
                            <span className="text-[10px] text-brand-text-secondary block mt-0.5">{p.package}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-5 px-6">
                        <span className="text-xs font-semibold block">{correspondingOrder?.customerName || "عميل كوديار"}</span>
                        <span className="text-[10px] text-slate-500 font-mono tracking-wider block mt-0.5" dir="ltr">{correspondingOrder?.phone || "بلا هاتف"}</span>
                      </td>
                      <td className="py-5 px-6">
                        <div className="flex items-center gap-2">
                          <input 
                            type="text" 
                            placeholder="لم يتم الربط" 
                            defaultValue={p.url || ""}
                            onBlur={(e) => updateProjectUrlDirectly(p.id, e.target.value)}
                            className="bg-brand-bg-primary text-xs h-8 px-2.5 rounded-lg border border-brand-border w-44 font-mono text-brand-text-primary focus:ring-1 focus:ring-brand-blue outline-none"
                          />
                          {p.url && (
                            <a href={p.url} target="_blank" rel="noreferrer" className="p-1.5 bg-brand-bg-secondary hover:bg-brand-bg-primary rounded-lg border border-brand-border text-brand-blue transition-colors">
                              <Globe size={12} />
                            </a>
                          )}
                        </div>
                      </td>
                      <td className="py-5 px-6 font-mono text-xs">
                        <span className="block">{p.expirationDate ? new Date(p.expirationDate).toLocaleDateString('en-GB') : "لا يوجد"}</span>
                        <span className={`text-[10px] font-bold block mt-0.5 ${expiryDays <= 10 ? "text-red-500" : "text-emerald-400"}`}>
                          {p.expirationDate ? `${expiryDays} يوم متبقي` : "مطلق"}
                        </span>
                      </td>
                      <td className="py-5 px-6">
                        <Link to={`/receipt/${p.id}`} className="inline-flex items-center gap-1 text-xs text-brand-orange hover:underline">
                          <FileText size={12} /> الفاتورة الموحدة
                        </Link>
                      </td>
                      <td className="py-5 px-6">
                        <span className={`text-xs px-2.5 py-1 rounded-full font-extrabold ${
                          p.status === 'active' ? 'bg-green-500/10 text-green-500' : 
                          p.status === 'suspended' ? 'bg-red-500/10 text-red-500' :
                          p.status === 'archived' ? 'bg-brand-bg-secondary text-brand-text-secondary border border-brand-border' :
                          'bg-orange-500/10 text-brand-orange border border-brand-orange/15'
                        }`}>
                          {p.status === 'active' ? 'نشط مفعل' : p.status === 'suspended' ? 'معلق ومحجوب' : p.status === 'archived' ? 'مؤرشف' : 'قيد التطوير'}
                        </span>
                      </td>
                      <td className="py-5 px-6 text-left">
                        <div className="flex items-center gap-2 justify-end">
                          <select 
                            value={p.status} 
                            onChange={(e) => updateProjectStatus(p.id, e.target.value)}
                            className="text-xs h-8 px-1.5 rounded-lg border border-brand-border bg-brand-bg-primary text-brand-text-primary focus:ring-1 focus:ring-brand-blue outline-none cursor-pointer"
                          >
                             <option value="pending">قيد المراجعة</option>
                             <option value="development">قيد التطوير</option>
                             <option value="active">نشط / مفعل</option>
                             <option value="completed">مكتمل</option>
                             <option value="suspended">معلق</option>
                             <option value="archived">أرشيف (محذوف)</option>
                          </select>
                          <Button onClick={() => hardDeleteProject(p.id)} size="xs" className="bg-red-500/10 hover:bg-red-500/20 text-red-500 border-none h-8 w-8 !p-0 shrink-0">
                            <Trash2 size={14} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* SECTION 3: INVOICES & ORDERS */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-brand-border">
          <CreditCard className="text-[#3b82f6]" size={20} />
          <h2 className="text-xl font-bold text-brand-text-primary">3. قسم الفواتير والطلبات المالية الموحدة</h2>
        </div>

        <div className="bg-brand-bg-secondary rounded-3xl border border-brand-border overflow-hidden">
          {/* Tabs indicators control */}
          <div className="flex border-b border-brand-border bg-brand-bg-secondary/45">
            <button 
              onClick={() => setInvoiceTab("active")}
              className={`flex-1 py-4 text-sm font-extrabold transition-colors border-b-2 ${
                invoiceTab === "active" ? "border-[#3b82f6] text-[#3b82f6] bg-[#0c101d]" : "border-transparent text-brand-text-secondary hover:text-brand-text-primary"
              }`}
            >
              الفواتير المفتوحة والمعلقة والنشطة ({orders.filter(o => o.status !== "cancelled" && o.status !== "completed").length})
            </button>
            <button 
              onClick={() => setInvoiceTab("inactive")}
              className={`flex-1 py-4 text-sm font-extrabold transition-colors border-b-2 ${
                invoiceTab === "inactive" ? "border-[#3b82f6] text-[#3b82f6] bg-[#0c101d]" : "border-transparent text-brand-text-secondary hover:text-brand-text-primary"
              }`}
            >
              الأرشيف والفواتير المكتملة والمجمدة ({orders.filter(o => o.status === "cancelled" || o.status === "completed").length})
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead>
                <tr className="border-b border-brand-border text-xs font-bold text-brand-text-secondary uppercase select-none">
                  <th className="py-4 px-6">معرف الفاتورة الموحد</th>
                  <th className="py-4 px-6">المستفيد</th>
                  <th className="py-4 px-6">اسم المشروع</th>
                  <th className="py-4 px-6">دليل الخصم</th>
                  <th className="py-4 px-6">طريقة الدفع</th>
                  <th className="py-4 px-6">تاريخ الإصدار</th>
                  <th className="py-4 px-6">السعر الإجمالي</th>
                  <th className="py-4 px-6">الحالة المالية</th>
                  <th className="py-4 px-6 text-left">التوجيه المستند المالي</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-border/40 font-semibold text-brand-text-primary">
                {orders
                  .filter(o => {
                    if (invoiceTab === "active") {
                      return o.status !== "cancelled" && o.status !== "completed";
                    } else {
                      return o.status === "cancelled" || o.status === "completed";
                    }
                  })
                  .map(o => (
                    <tr key={o.id} className="hover:bg-brand-bg-primary/40 transition-colors">
                      <td className="py-5 px-6 font-mono text-xs font-bold text-brand-blue">{o.id}</td>
                      <td className="py-5 px-6">
                        <span className="block font-bold">{o.customerName}</span>
                        <span className="text-[10px] text-brand-text-secondary block font-mono" dir="ltr">{o.phone}</span>
                      </td>
                      <td className="py-5 px-6">
                        <span className="block font-bold text-slate-100">{o.projectName}</span>
                        <span className="text-[10px] text-[#F97316] block mt-0.5">{o.package} / {o.duration}</span>
                      </td>
                      <td className="py-5 px-6">
                        {o.proofLink ? (
                          <div className="flex flex-col gap-2 relative">
                            <a href={o.proofLink} target="_blank" rel="noreferrer" className="text-brand-orange hover:underline text-xs flex items-center gap-1">
                              <Eye size={12} /> عرض الدليل
                            </a>
                            <Button onClick={() => openDiscountModal(o)} size="xs" className="text-[10px] h-6 px-2 w-max bg-brand-bg-primary text-brand-text-primary border border-brand-orange/30 hover:border-brand-orange">
                               مراجعة طلب الخصم
                            </Button>
                          </div>
                        ) : (
                          <span className="text-brand-text-secondary text-xs">لا يوجد</span>
                        )}
                      </td>
                      <td className="py-5 px-6 font-semibold text-xs text-brand-blue">{o.paymentMethod || "زين كاش"}</td>
                      <td className="py-5 px-6 font-mono text-xs text-slate-400">{new Date(o.createdAt).toLocaleDateString("en-GB")}</td>
                      <td className="py-5 px-6 font-mono text-[13px] font-black">{formatIraqiDinar(o.total)}</td>
                      <td className="py-5 px-6">
                        <select 
                          value={o.status}
                          onChange={(e) => updateOrderStatus(o.id, e.target.value)}
                          className="text-xs h-8 px-1.5 rounded-lg border border-brand-border bg-brand-bg-primary text-brand-text-primary focus:ring-1 focus:ring-brand-blue outline-none cursor-pointer"
                        >
                          <option value="unpaid">بانتظار السداد</option>
                          <option value="pending">تحت المراجعة</option>
                          <option value="paid">تم الدفع / مدفوع</option>
                          <option value="cancelled">ملغي ومسترد</option>
                        </select>
                      </td>
                      <td className="py-5 px-6 text-left">
                        <div className="flex items-center gap-2">
                          <Button 
                            onClick={() => setShowQrForInvoice(o.id)}
                            size="xs" 
                            variant="outline" 
                            className="bg-[#111827]/80 hover:bg-[#1E293B] border-brand-border text-brand-text-primary text-xs font-bold h-8 px-2"
                          >
                            <ScanQrCode size={12} className="ml-1" />
                            الرمز
                          </Button>
                          <Link to={`/receipt/${o.id}`}>
                            <Button size="xs" variant="outline" className="border-brand-border text-brand-text-primary hover:bg-brand-bg-primary text-xs font-bold h-8 px-3">
                              <Eye size={12} className="ml-1" />
                              فتح المستند
                            </Button>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {orders.filter(o => {
                    if (invoiceTab === "active") {
                      return o.status !== "cancelled" && o.status !== "completed";
                    } else {
                      return o.status === "cancelled" || o.status === "completed";
                    }
                  }).length === 0 && (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-brand-text-secondary text-xs">لا توجد فواتير لتصنيف التبويب الحالي.</td>
                    </tr>
                  )}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* SECTION 4: FINANCIAL CENTER */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-brand-border">
          <TrendingUp className="text-[#3b82f6]" size={20} />
          <h2 className="text-xl font-bold text-brand-text-primary">4. المركز المالي وعقود التجديد السنوية</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Cash Flow Ledger Card */}
          <div className="bg-brand-bg-secondary p-6 rounded-3xl border border-brand-border space-y-4">
            <h3 className="text-base font-black text-brand-text-primary pb-2 border-b border-brand-border">التدفقات النقدية والتحصيلات الرصينة</h3>
            
            <div className="divide-y divide-brand-border/40 text-xs">
              <div className="flex justify-between items-center py-3">
                <span className="text-brand-text-secondary">الإيراد الحالي للشهر المالي الجاري</span>
                <span className="font-mono font-bold text-sm text-emerald-400">{formatIraqiDinar(monthlyRevenueTotal)}</span>
              </div>
              <div className="flex justify-between items-center py-3">
                <span className="text-brand-text-secondary">الإيراد السنوي الإجمالي التراكمي ({currentYear})</span>
                <span className="font-mono font-bold text-sm text-emerald-400">{formatIraqiDinar(yearlyRevenueTotal)}</span>
              </div>
              <div className="flex justify-between items-center py-3">
                <span className="text-brand-text-secondary">العقود النشطة بالدفع المتكرر</span>
                <span className="font-mono font-semibold text-sm">{activeProjectsList.length} اشتراك</span>
              </div>
            </div>
          </div>

          {/* Renewals Alert list */}
          <div className="bg-brand-bg-secondary p-6 rounded-3xl border border-[#F97316]/10 space-y-4">
            <h3 className="text-base font-black text-[#F97316] pb-2 border-b border-[#F97316]/10 flex items-center gap-1.5">
              <AlertCircle size={16} />
              بوابات التجديد الوشيك (30 يوم القادمة)
            </h3>

            {upcomingRenewalsList.length === 0 ? (
              <div className="py-8 text-center text-xs text-brand-text-secondary font-semibold">
                لا توجد نطاقات أو خوادم لعملاء تنتهي خلال الثلاثين يوماً القادمة.
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingRenewalsList.map(p => (
                  <div key={p.id} className="p-3 bg-[#111827]/40 border border-brand-border/80 rounded-xl flex items-center justify-between">
                    <div>
                      <span className="font-bold block text-xs">{p.name}</span>
                      <span className="text-[10px] text-brand-text-secondary">{p.package} • {p.type}</span>
                    </div>
                    <span className="text-[10px] bg-red-500/10 text-red-500 px-2 py-0.5 rounded font-mono font-bold">
                      ينتهي في: {new Date(p.expirationDate!).toLocaleDateString("en-GB")}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* SECTION 5: LIVE STATS */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-brand-border">
          <Activity className="text-[#3b82f6]" size={20} />
          <h2 className="text-xl font-bold text-brand-text-primary">5. غرف المراقبة والإحصائيات المباشرة (Live Stats)</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="bg-brand-bg-secondary p-6 rounded-2xl border border-brand-border text-center flex flex-col justify-between">
            <span className="text-[10px] text-logo-gold font-bold uppercase tracking-widest block">إجمالي الإيرادات المنفذة</span>
            <span className="text-lg font-black text-emerald-400 font-mono tracking-tight block mt-3">{formatIraqiDinar(totalRevenue)}</span>
          </div>
          <div className="bg-brand-bg-secondary p-6 rounded-2xl border border-brand-border text-center flex flex-col justify-between">
            <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-widest block">سلة الطلبات الموحدة</span>
            <span className="text-3xl font-black text-brand-text-primary font-mono block mt-3">{orders.length}</span>
          </div>
          <div className="bg-brand-bg-secondary p-6 rounded-2xl border border-brand-border text-center flex flex-col justify-between">
            <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-widest block font-bold text-brand-orange">فواتير معلقة السداد</span>
            <span className="text-3xl font-black text-brand-orange font-mono block mt-3">{outstandingInvoicesCount}</span>
          </div>
          <div className="bg-brand-bg-secondary p-6 rounded-2xl border border-[#3b82f6]/10 text-center flex flex-col justify-between">
            <span className="text-[10px] text-brand-blue font-bold uppercase tracking-widest block">الخوادم النشطة</span>
            <span className="text-3xl font-black text-[#3b82f6] font-mono block mt-3">{activeProjectsList.length}</span>
          </div>
          <div className="bg-brand-bg-secondary p-6 rounded-2xl border border-brand-border text-center flex flex-col justify-between relative overflow-hidden">
            <span className="text-[10px] text-brand-text-secondary font-bold uppercase tracking-widest block">الزيارات الشهرية واليومية للمنصة</span>
            <div className="mt-3 flex justify-around items-center font-mono">
              <div>
                <span className="text-xs text-brand-text-secondary block font-bold">شهرياً</span>
                <span className="text-sm font-black text-white font-mono">18,482</span>
              </div>
              <div className="h-6 w-px bg-slate-800"></div>
              <div>
                <span className="text-xs text-brand-text-secondary block font-bold">يومياً</span>
                <span className="text-sm font-black text-[#F97316] font-mono">1,209</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 6: REVIEW MODERATION */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 pb-2 border-b border-brand-border">
          <MessageSquare className="text-[#3b82f6]" size={20} />
          <h2 className="text-xl font-bold text-brand-text-primary">6. إدارة تقييمات شركاء النجاح</h2>
        </div>

        <div className="bg-brand-bg-secondary rounded-3xl border border-brand-border overflow-hidden">
          <div className="p-6 border-b border-brand-border bg-brand-bg-secondary/45">
            <h3 className="text-base font-black text-brand-text-primary">متابعة ومراجعة تقييمات العملاء قبل النشر</h3>
            <p className="text-xs text-brand-text-secondary font-medium mt-1">يجب قبول التقييم ليظهر للعامة في الصفحة الرئيسية</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
              <thead>
                <tr className="border-b border-brand-border text-xs font-bold text-brand-text-secondary uppercase select-none">
                  <th className="py-4 px-6">العميل</th>
                  <th className="py-4 px-6">التقييم</th>
                  <th className="py-4 px-6 max-w-[300px]">التعليق</th>
                  <th className="py-4 px-6">تاريخ الإرسال</th>
                  <th className="py-4 px-6">الحالة</th>
                  <th className="py-4 px-6 text-left">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-border/40 font-semibold text-brand-text-primary">
                {reviews.map(r => (
                  <tr key={r.id} className="hover:bg-brand-bg-primary/40 transition-colors">
                    <td className="py-5 px-6">
                      <span className="block font-bold">{r.clientName}</span>
                    </td>
                    <td className="py-5 px-6">
                      <div className="flex gap-1 text-[#FADB14]">
                        {[...Array(r.stars || 5)].map((_, i) => (
                           <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-[14px] h-[14px]">
                             <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96-1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                           </svg>
                        ))}
                      </div>
                    </td>
                    <td className="py-5 px-6 max-w-[300px]">
                      <p className="text-xs text-brand-text-secondary leading-relaxed line-clamp-3">"{r.comment}"</p>
                    </td>
                    <td className="py-5 px-6 font-mono text-xs text-slate-400">{new Date(r.createdAt).toLocaleDateString("en-GB")}</td>
                    <td className="py-5 px-6">
                      <span className={`text-xs px-2.5 py-1 rounded-full font-extrabold ${
                        r.status === 'approved' ? 'bg-green-500/10 text-green-500' : 
                        r.status === 'rejected' ? 'bg-red-500/10 text-red-500' :
                        'bg-brand-orange/10 text-brand-orange'
                      }`}>
                        {r.status === 'approved' ? 'مقبول ونشط' : r.status === 'rejected' ? 'مرفوض' : 'قيد المراجعة'}
                      </span>
                    </td>
                    <td className="py-5 px-6 text-left">
                      <div className="flex items-center gap-2 justify-end">
                        {r.status !== 'approved' && (
                          <Button onClick={() => updateReviewStatus(r.id, 'approved')} size="xs" className="bg-green-500/10 hover:bg-green-500/20 text-green-500 border-none h-8 w-8 !p-0">
                            <ThumbsUp size={14} />
                          </Button>
                        )}
                        {r.status !== 'rejected' && (
                          <Button onClick={() => updateReviewStatus(r.id, 'rejected')} size="xs" className="bg-orange-500/10 hover:bg-orange-500/20 text-orange-500 border-none h-8 w-8 !p-0">
                            <ThumbsDown size={14} />
                          </Button>
                        )}
                        <Button onClick={() => deleteReview(r.id)} size="xs" className="bg-red-500/10 hover:bg-red-500/20 text-red-500 border-none h-8 w-8 !p-0">
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
                {reviews.length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-brand-text-secondary text-xs">لا يوجد تقييمات حالياً</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>

    </div>
  );
}
