import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { useAuth } from "../hooks/useAuth";
import { Button } from "../components/ui/Button";
import { db, handleFirestoreError, OperationType, signInWithGoogle } from "../lib/firebase";
import { doc, setDoc } from "firebase/firestore";
import type { Order } from "../types";
import { Check, ChevronLeft, CreditCard, Box, Briefcase } from "lucide-react";

const categories = [
  "مواقع المطاعم والمنيو",
  "مواقع العيادات",
  "المتاجر الإلكترونية",
  "المواقع الشخصية (Portfolio)",
  "أخرى"
];

const packages = [
  "دعم المشاريع المنزلية (خصم 100% - أقل من 15 طلب شهرياً)",
  "دعم المشاريع المنزلية (خصم 50% - أقل من 50 طلب شهرياً)", 
  "الباقة الأساسية (Basic)", 
  "الباقة الذهبية (Gold)", 
  "الباقة الاحترافية (Pro)", 
  "الباقة الفاخرة (Premium)"
];
const durations = ["1 شهر", "3 أشهر (خصم 5%)", "6 أشهر (خصم 10%)", "12 شهر (خصم 25%)"];
const paymentMethods = ["زين كاش", "آسيا حوالة", "سوبر كي", "القاصة", "Neo", "كارت تعبئة", "تحويل رصيد"];

export default function OrderPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [customCategory, setCustomCategory] = useState("");

  const [formData, setFormData] = useState({
    customerName: user?.displayName || "",
    phone: "",
    projectName: "",
    category: categories[0],
    subscriptionPackage: packages[3], // Default to Gold
    duration: durations[0],
    description: "",
    proofLink: "",
    paymentMethod: paymentMethods[0],
  });

  if (!user) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center p-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-brand-bg-secondary p-10 rounded-3xl shadow-xl shadow-brand-blue/5 border border-brand-border max-w-md w-full text-center">
          <div className="w-20 h-20 bg-brand-blue/10 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
            <svg className="w-10 h-10 text-brand-blue" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-3xl font-extrabold text-brand-text-primary mb-3">حياك الله معنا</h2>
          <p className="text-brand-text-secondary mb-10 font-medium leading-relaxed">الرجاء تسجيل الدخول للبدء في صياغة مشروعك الرقمي القادم وإدارة اشتراكاتك.</p>
          <Button onClick={signInWithGoogle} size="lg" className="w-full text-md shadow-lg shadow-brand-blue/20">تسجيل الدخول والمتابعة</Button>
        </motion.div>
      </div>
    );
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const nextStep = () => {
    setError("");
    if (step === 1) {
      if (!formData.customerName || !formData.phone) {
        setError("يرجى تعبئة الاسم ورقم الهاتف للبدء بإنشاء ملفك.");
        return;
      }
      const cleanPhone = formData.phone.trim().replace(/\s+/g, '');
      if (!/^(078|077|079|075)\d{8}$/.test(cleanPhone)) {
        setError("رقم الهاتف غير صالح. يجب أن يكون رقماً عراقياً مكوناً من 11 رقماً ويبدأ بـ (078 أو 077 أو 079 أو 075).");
        return;
      }
    }
    if (step === 2 && !formData.projectName) {
      setError("كيف يمكننا الإشارة إلى مشروعك الجميل؟ (الرجاء إدخال الاسم).");
      return;
    }
    setStep(s => s + 1);
  };

  const prevStep = () => setStep(s => s - 1);

  const generateId = (prefix: string, length: number) => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return `${prefix}-${result}`;
  };

  // Pricing calculations
  let pkgPrice = 0;
  if (formData.subscriptionPackage.includes("الأساسية") || formData.subscriptionPackage.includes("دعم المشاريع المنزلية")) pkgPrice = 15000;
  else if (formData.subscriptionPackage.includes("الذهبية")) pkgPrice = 19000;
  else if (formData.subscriptionPackage.includes("الاحترافية")) pkgPrice = 39000;
  else if (formData.subscriptionPackage.includes("الفاخرة")) pkgPrice = 79000;

  let months = 1;
  let discountPercent = 0;
  
  if (formData.duration.includes("3")) months = 3;
  else if (formData.duration.includes("6")) months = 6;
  else if (formData.duration.includes("12")) months = 12;

  if (formData.subscriptionPackage.includes("خصم 100%")) {
    discountPercent = 100;
  } else if (formData.subscriptionPackage.includes("خصم 50%")) {
    discountPercent = 50;
  } else {
    if (months === 3) discountPercent = 5;
    else if (months === 6) discountPercent = 10;
    else if (months === 12) discountPercent = 25;
  }

  const totalBase = pkgPrice * months;
  const discountVal = Math.round(totalBase * (discountPercent / 100));
  const finalTotal = totalBase - discountVal;

  const generateOrder = async () => {
    try {
      setLoading(true);
      setError("");
      
      // Single unified ID format: ORD-2026-KI944
      const currentYear = new Date().getFullYear();
      const generateUnifiedId = () => {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        let result = '';
        for (let i = 0; i < 5; i++) {
          result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return `ORD-${currentYear}-${result}`;
      };
      
      const unifiedId = generateUnifiedId();
      const orderId = unifiedId;
      const receiptId = unifiedId;
      const projectId = unifiedId;
      
      // Calculate active dates for Project:
      const activationDate = Date.now();
      const expirationDate = activationDate + (months * 30 * 24 * 60 * 60 * 1000);

      const finalCategory = formData.category === "أخرى" ? (customCategory.trim() || "آخر") : formData.category;

      // Create physical Project matching requirements
      const newProject = {
        id: projectId,
        clientId: user.uid,
        name: formData.projectName,
        type: finalCategory,
        status: "pending",
        statusList: ["pending"],
        package: formData.subscriptionPackage,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        orderId,
        receiptId,
        activationDate,
        expirationDate,
        url: ""
      };

      await setDoc(doc(db, "projects", projectId), newProject);

      const newOrder: Order = {
        id: orderId,
        clientId: user.uid,
        customerName: formData.customerName,
        phone: formData.phone,
        projectName: formData.projectName,
        category: finalCategory,
        package: formData.subscriptionPackage,
        duration: formData.duration,
        description: formData.description,
        proofLink: formData.proofLink,
        paymentMethod: formData.paymentMethod,
        status: "unpaid",
        statusList: ["unpaid"],
        total: finalTotal,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        projectId,
        receiptId
      };

      await setDoc(doc(db, "orders", orderId), newOrder);
      
      await setDoc(doc(db, "receipts", receiptId), {
        id: receiptId,
        orderId,
        clientId: user.uid,
        status: "unpaid",
        statusList: ["unpaid"],
        total: finalTotal,
        createdAt: Date.now(),
        projectId
      });

      navigate(`/receipt/${receiptId}`);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'orders');
      setError("حدث خطأ في إنشاء الطلب، يرجى المحاولة لاحقاً.");
    } finally {
      setLoading(false);
    }
  };

  const stepsInfo = [
    { num: 1, title: 'البيانات الشخصية', icon: <UserIcon /> },
    { num: 2, title: 'نطاق المشروع', icon: <Briefcase /> },
    { num: 3, title: 'الدفع والفاتورة', icon: <CreditCard /> },
  ];

  return (
    <div className="max-w-4xl mx-auto py-16 px-4 sm:px-6">
      
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-extrabold text-brand-text-primary tracking-tight mb-4 tracking-tight">إنشاء طلب جديد</h1>
        <p className="text-brand-text-secondary text-lg">بضع خطوات بسيطة تفصلك عن إطلاق هويتك الرقمية.</p>
      </div>

      <div className="bg-brand-bg-secondary rounded-3xl shadow-lg border border-brand-border overflow-hidden">
        
        {/* Progress Timeline */}
        <div className="bg-brand-bg-primary/50 flex items-center justify-between px-8 py-6 border-b border-brand-border/60">
          {stepsInfo.map((s, idx) => (
            <div key={s.num} className="flex flex-col items-center flex-1 relative">
              {idx !== 0 && (
                 <div className={`absolute top-5 right-[50%] w-full h-[2px] transition-colors duration-500 -z-10 ${step >= s.num ? 'bg-brand-blue' : 'bg-brand-border'}`}></div>
              )}
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-500 shadow-sm z-10 
                ${step > s.num ? 'bg-brand-blue text-white ring-4 ring-brand-blue/20' : 
                  step === s.num ? 'bg-brand-text-primary text-brand-bg-primary ring-4 ring-brand-text-primary/20 scale-110' : 
                  'bg-brand-bg-secondary border-2 border-brand-border text-brand-text-secondary'}`}>
                {step > s.num ? <Check size={18} /> : s.num}
              </div>
              <span className={`mt-3 text-xs font-bold ${step >= s.num ? 'text-brand-text-primary' : 'text-brand-text-secondary'}`}>{s.title}</span>
            </div>
          ))}
        </div>

        <div className="p-8 md:p-14">
          <AnimatePresence mode="wait">
            {error && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-8">
                <div className="p-4 bg-red-500/10 text-red-500 border border-red-500/30 rounded-xl text-sm font-bold flex items-center gap-3">
                   <div className="w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center">!</div>
                  {error}
                </div>
              </motion.div>
            )}

            {step === 1 && (
               <motion.div key="step1" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ duration: 0.3 }}>
                 <h2 className="text-3xl font-extrabold text-brand-text-primary mb-8">لمن لمن هذا الإبداع؟</h2>
                 <div className="space-y-6">
                   <div>
                     <label className="block text-sm font-bold text-brand-text-secondary mb-2">الاسم الكامل</label>
                     <input type="text" name="customerName" value={formData.customerName} onChange={handleChange} placeholder="اكتب اسمك الحقيقي..." className="w-full text-lg h-14 rounded-xl border border-brand-border bg-brand-bg-primary px-4 focus:ring-2 focus:ring-brand-blue outline-none transition-all focus:border-brand-blue text-brand-text-primary" />
                   </div>
                   <div>
                     <label className="block text-sm font-bold text-brand-text-secondary mb-2">رقم الهاتف (للتواصل عبر واتساب)</label>
                     <input type="tel" name="phone" value={formData.phone} onChange={handleChange} dir="ltr" placeholder="+964 7XX XXX XXXX" className="w-full text-lg h-14 rounded-xl border border-brand-border bg-brand-bg-primary px-4 focus:ring-2 focus:ring-brand-blue outline-none transition-all focus:border-brand-blue text-left font-mono tracking-wide text-brand-text-primary" />
                   </div>
                 </div>
               </motion.div>
            )}

            {step === 2 && (
               <motion.div key="step2" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ duration: 0.3 }}>
                 <h2 className="text-3xl font-extrabold text-brand-text-primary mb-8">هيكل المشروع</h2>
                 <div className="space-y-8">
                   
                   <div>
                     <label className="block text-sm font-bold text-brand-text-secondary mb-2">اسم المشروع / العلامة التجارية</label>
                     <input type="text" name="projectName" value={formData.projectName} onChange={handleChange} placeholder="مثال: La Paris Cafe" className="w-full text-lg h-14 rounded-xl border border-brand-border bg-brand-bg-primary px-4 focus:ring-2 focus:ring-brand-blue outline-none transition-all text-brand-text-primary" />
                   </div>
                   
                   <div>
                     <label className="block text-sm font-bold text-brand-text-secondary mb-3">تصنيف المشروع</label>
                      {formData.category === "أخرى" && (
                        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-4">
                          <label className="block text-sm font-bold text-brand-text-secondary mb-2">نوع المشروع المخصص (اكتبه يدوياً)</label>
                          <input 
                            type="text" 
                            value={customCategory} 
                            onChange={(e) => setCustomCategory(e.target.value)} 
                            placeholder="مثال: تطبيق للمقاولات، منصة عقارات عراقية..." 
                            className="w-full text-md h-12 rounded-xl border border-brand-border bg-brand-bg-primary px-4 focus:ring-2 focus:ring-brand-blue outline-none text-brand-text-primary mb-4" 
                          />
                        </motion.div>
                      )}
                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                       {categories.map(c => (
                         <div key={c} onClick={() => setFormData(prev => ({ ...prev, category: c }))} className={`cursor-pointer rounded-xl border p-4 transition-all flex items-center gap-3 ${formData.category === c ? 'border-brand-blue bg-brand-blue/10 text-brand-blue ring-1 ring-brand-blue shadow-sm' : 'border-brand-border bg-brand-bg-primary text-brand-text-primary hover:border-brand-blue/50'}`}>
                           <Box size={18} className={formData.category === c ? 'text-brand-blue' : 'text-brand-text-secondary'} />
                           <span className="font-bold text-sm tracking-wide">{c}</span>
                         </div>
                       ))}
                     </div>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 rounded-2xl bg-brand-bg-primary border border-brand-border">
                     <div>
                       <label className="block text-sm font-bold text-brand-text-secondary mb-2">الباقة المطلوبة</label>
                       <select name="subscriptionPackage" value={formData.subscriptionPackage} onChange={handleChange} className="w-full text-md h-12 rounded-lg border border-brand-border bg-brand-bg-secondary px-3 focus:ring-2 outline-none text-brand-text-primary hover:border-brand-blue/50 cursor-pointer">
                         {packages.map(p => <option key={p} value={p}>{p}</option>)}
                       </select>
                     </div>
                     <div>
                       <label className="block text-sm font-bold text-brand-text-secondary mb-2">مدة التجديد والاشتراك</label>
                       <select name="duration" value={formData.duration} onChange={handleChange} className="w-full text-md h-12 rounded-lg border border-brand-border bg-brand-bg-secondary px-3 focus:ring-2 outline-none text-brand-text-primary hover:border-brand-blue/50 cursor-pointer">
                         {durations.map(d => <option key={d} value={d}>{d}</option>)}
                       </select>
                     </div>
                   </div>

                   <div>
                     <label className="block text-sm font-bold text-brand-text-secondary mb-2">وصف تنفيذي (اختياري)</label>
                     <textarea name="description" value={formData.description} onChange={handleChange} rows={3} placeholder="اكتب بعض التفاصيل حول احتياجاتك الخاصة..." className="w-full rounded-xl border border-brand-border bg-brand-bg-primary px-4 py-3 text-lg focus:ring-2 outline-none resize-none transition-all text-brand-text-primary"></textarea>
                   </div>
                   
                   {formData.subscriptionPackage.includes("خصم") && (
                     <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="p-5 border border-brand-orange bg-brand-orange/5 rounded-2xl">
                       <label className="block text-sm font-bold text-brand-orange mb-2">رابط إثبات نشاط المشروع كدليل (مطلوب للخصم)</label>
                       <p className="text-xs text-brand-orange/80 mb-3">يرجى توفير رابط إنستغرام أو فيسبوك للمشروع لإثبات أنه مشروع ناشئ يستحق الخصم.</p>
                       <input 
                         type="url" 
                         name="proofLink" 
                         value={formData.proofLink} 
                         onChange={handleChange} 
                         placeholder="https://instagram.com/your_project" 
                         className="w-full text-md h-12 rounded-xl border border-brand-orange/30 bg-brand-bg-primary px-4 focus:ring-2 focus:ring-brand-orange outline-none text-brand-text-primary" 
                         required
                       />
                     </motion.div>
                   )}
                 </div>
               </motion.div>
            )}

            {step === 3 && (
               <motion.div key="step3" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ duration: 0.3 }}>
                 <h2 className="text-3xl font-extrabold text-brand-text-primary mb-6">مراجعة التكلفة والفوترة</h2>
                 
                 {/* Premium interactive price breakdown card */}
                 <div className="bg-[#111827] border border-brand-border rounded-2xl p-6 mb-8 shadow-inner">
                     <h3 className="font-bold text-base mb-4 text-brand-text-primary border-b border-brand-border/40 pb-2">تفاصيل الفاتورة الرسمية</h3>
                     <div className="space-y-3.5 text-sm font-medium">
                        <div className="flex justify-between">
                           <span className="text-brand-text-secondary">اسم المشروع:</span>
                           <span className="text-brand-text-primary font-bold">{formData.projectName}</span>
                        </div>
                        <div className="flex justify-between">
                           <span className="text-brand-text-secondary">الباقة المحددة:</span>
                           <span className="text-brand-text-primary font-bold">{formData.subscriptionPackage}</span>
                        </div>
                        <div className="flex justify-between">
                           <span className="text-brand-text-secondary">مدة الاشتراك:</span>
                           <span className="text-brand-text-primary font-semibold text-brand-blue">{formData.duration}</span>
                        </div>
                        <hr className="border-brand-border/40" />
                        <div className="flex justify-between text-brand-text-secondary text-xs">
                           <span>السعر الأساسي لكل شهر:</span>
                           <span className="font-mono">{pkgPrice.toLocaleString()} د.ع</span>
                        </div>
                        <div className="flex justify-between text-brand-text-secondary text-xs">
                           <span>عدد الأشهر الإجمالي:</span>
                           <span className="font-semibold">{months} أشهر</span>
                        </div>
                        {discountPercent > 0 && (
                          <div className="flex justify-between text-green-500 font-bold text-xs bg-green-500/5 px-3 py-1.5 rounded-lg border border-green-500/10">
                             <span>خصم التجديد الاستثماري المميز ({discountPercent}%):</span>
                             <span className="font-mono">-{discountVal.toLocaleString()} د.ع</span>
                          </div>
                        )}
                        <div className="flex justify-between text-lg font-bold text-brand-text-primary pt-3 border-t border-brand-border/60">
                           <span>القيمة الكلية للاستثمار:</span>
                           <span className="text-brand-orange font-mono text-xl">{finalTotal.toLocaleString()} د.ع</span>
                        </div>
                     </div>
                 </div>

                 <h3 className="text-xl font-bold text-brand-text-primary mb-4">طريقة السداد المفضلة</h3>
                 <div className="grid grid-cols-2 gap-4 mb-8">
                    {paymentMethods.map(method => (
                      <div 
                        key={method}
                        onClick={() => setFormData(prev => ({ ...prev, paymentMethod: method }))}
                        className={`cursor-pointer rounded-2xl border p-5 flex flex-col items-center justify-center gap-3 transition-all ${formData.paymentMethod === method ? 'border-brand-orange bg-brand-orange/10 text-brand-text-primary ring-2 ring-brand-orange shadow-md' : 'border-brand-border bg-brand-bg-primary text-brand-text-secondary hover:border-brand-text-secondary'}`}
                      >
                        <CreditCard size={24} className={formData.paymentMethod === method ? 'text-brand-orange' : 'text-brand-text-secondary/50'} />
                        <span className="font-bold tracking-wide text-xs">{method}</span>
                      </div>
                    ))}
                 </div>
                 
                 <div className="bg-brand-blue/5 p-6 rounded-2xl border border-brand-blue/20 text-center">
                    <p className="text-lg font-bold text-brand-text-primary mb-2">دفع آمن، تأكيد فوري</p>
                    <p className="text-xs text-brand-text-secondary leading-relaxed font-semibold">سيتم إستصدار فاتورتك فور النقر على "إنشاء وتأكيد الفاتورة" بالأسفل، يرجى حفظها متبوعة بإكمال التقرير الرسمي عبر رائد التفعيل المباشر على واتساب لتنفيذ الخدمة البرمجية فورياً.</p>
                 </div>
               </motion.div>
            )}
          </AnimatePresence>

          <div className="flex justify-between items-center mt-12 pt-8 border-t border-brand-border">
            {step > 1 ? (
              <Button variant="outline" onClick={prevStep} size="lg" className="px-8 text-brand-text-secondary hover:text-brand-text-primary group border-brand-border hover:bg-brand-bg-primary">
                <ChevronLeft className="w-4 h-4 ml-2 transition-transform group-hover:-translate-x-1" />
                السابق
              </Button>
            ) : <div></div>}

            {step < 3 ? (
              <Button onClick={nextStep} size="lg" className="px-12 bg-brand-text-primary text-brand-bg-primary hover:bg-brand-text-secondary shadow-lg font-bold">التالي</Button>
            ) : (
              <Button onClick={generateOrder} isLoading={loading} size="lg" className="px-12 bg-brand-blue hover:bg-blue-600 text-white shadow-xl shadow-brand-blue/30 font-bold text-md">
                إنشاء وتأكيد الفاتورة
              </Button>
            )}
          </div>

        </div>
      </div>
    </div>
  );
}

function UserIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
  );
}
