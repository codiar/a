import { motion } from "motion/react";
import { CheckCircle2, Shield, Zap, HeartHandshake, TrendingUp, Users } from "lucide-react";
import { Link } from "react-router-dom";

export default function About() {
  return (
    <div className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-20"
      >
        <h1 className="text-4xl md:text-5xl font-black text-brand-text-primary mb-6">من نحن - Codiar Tech</h1>
        <p className="text-xl text-brand-text-secondary max-w-3xl mx-auto font-medium leading-relaxed">
          نحن فريق عراقي شغوف بتحويل الأفكار إلى واقع رقمي مبهر. في كوديار تك، لا نبني مجرد مواقع وتطبيقات، بل نصنع تجارب رقمية تليق بعلامتك التجارية وتساهم في نمو أعمالك.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mb-24">
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-brand-bg-secondary p-8 md:p-12 rounded-3xl border border-brand-border"
        >
          <div className="w-16 h-16 bg-brand-orange/10 text-brand-orange rounded-2xl flex items-center justify-center mb-6">
            <TrendingUp size={32} />
          </div>
          <h2 className="text-3xl font-bold mb-4 text-brand-text-primary">رؤيتنا</h2>
          <p className="text-brand-text-secondary text-lg leading-relaxed font-medium">
            أن نكون الخيار الأول للشركات والمشاريع الطموحة في العراق والوطن العربي، من خلال تقديم حلول برمجية مبتكرة وعالية الجودة تساهم في تحقيق التحول الرقمي الشامل والمتطور.
          </p>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-brand-bg-secondary p-8 md:p-12 rounded-3xl border border-brand-border"
        >
          <div className="w-16 h-16 bg-brand-blue/10 text-brand-blue rounded-2xl flex items-center justify-center mb-6">
            <HeartHandshake size={32} />
          </div>
          <h2 className="text-3xl font-bold mb-4 text-brand-text-primary">رسالتنا</h2>
          <p className="text-brand-text-secondary text-lg leading-relaxed font-medium">
            تمكين المشاريع المحلية من المنافسة بقوة في السوق الرقمي، عبر تقديم باقات استثمارية مرنة، وتطوير أنظمة آمنة وسريعة تلبي احتياجات المستخدمين وتضمن نجاح الأعمال.
          </p>
        </motion.div>
      </div>

      <div className="mb-24">
        <h2 className="text-3xl font-bold text-center text-brand-text-primary mb-12">لماذا تختار كوديار تك؟</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: <Zap size={24} />, title: "سرعة وأداء فائق", desc: "نستخدم أحدث التقنيات لضمان أداء يخطف الأنفاس." },
            { icon: <Shield size={24} />, title: "حماية وأمان موثوق", desc: "بياناتك وبيانات عملائك في أمان تام." },
            { icon: <Users size={24} />, title: "دعم فني متميز", desc: "نحن هنا لمساعدتك في أي وقت لتخطي العقبات." },
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.1 }}
              className="bg-brand-bg-secondary border border-brand-border p-8 rounded-2xl flex flex-col items-center text-center"
            >
              <div className="w-14 h-14 bg-brand-bg-primary border border-brand-border rounded-full flex items-center justify-center text-brand-text-primary mb-4">
                {item.icon}
              </div>
              <h3 className="text-xl font-bold mb-2 text-brand-text-primary">{item.title}</h3>
              <p className="text-brand-text-secondary font-medium">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="text-center bg-gradient-to-br from-brand-bg-secondary to-brand-bg-primary border border-brand-border rounded-[3rem] p-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-orange/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-blue/5 rounded-full blur-3xl pointer-events-none"></div>
        <h2 className="text-3xl md:text-4xl font-black text-brand-text-primary mb-6 relative z-10">مستعد للبدء في مشروعك القادم؟</h2>
        <p className="text-lg text-brand-text-secondary mb-10 max-w-2xl mx-auto relative z-10">
          دعنا نضع خبراتنا في متناول يديك. نحن مستعدون لتطوير تطبيقك أو موقعك بأفضل معايير الجودة الممكنة.
        </p>
        <Link to="/order" className="relative z-10 inline-block px-10 py-4 bg-brand-text-primary text-brand-bg-primary rounded-xl font-bold hover:scale-105 transition-transform shadow-xl">
          احجز استشارة مجانية
        </Link>
      </div>

    </div>
  )
}
