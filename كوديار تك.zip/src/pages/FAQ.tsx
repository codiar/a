import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronDown, HelpCircle } from "lucide-react";

export default function FAQ() {
  const faqs = [
    {
      q: "ما هي مدة تنفيذ المشروع وبرمجته؟",
      a: "تختلف المدة حسب حجم وتفاصيل المشروع. المواقع التعريفية البسيطة والمنيوهات تأخذ بين 3 إلى 7 أيام، بينما المنصات والتطبيقات المخصصة قد تستغرق من أسبوعين إلى عدة أشهر. يتم تزويدك بجدول زمني دقيق بعد تحديد المتطلبات."
    },
    {
      q: "ما هي طرق وأساليب الدفع المتاحة لديكم؟",
      a: "نقبل الدفع عبر حوالات زين كاش، أو التحويل البنكي المباشر داخل العراق، بالإضافة إلى إمكانية الاستلام نقداً في مقرنا للمشاريع الكبيرة."
    },
    {
      q: "هل تقدمون خدمات الاستضافة وحجز النطاق (الدومين)؟",
      a: "نعم، معظم باقات تصميم المواقع لدينا تتضمن استضافة سحابية عالية الأداء ونطاق (Domain) مجاني للسنة الأولى لنسهل عليك بدء نشاطك الرقمي."
    },
    {
      q: "هل يمكنني تعديل محتوى موقعي بنفسي بعد استلامه؟",
      a: "بالتأكيد، إن كنت اخترت الباقة التي تتضمن لوحة تحكم، سيتم تزويدك بلوحة إدارية بسيطة باللغة العربية تتيح لك تعديل النصوص، إضافة الصور، وتحديث المنتجات دون أي خبرة برمجية مسبقة، بالإضافة لفيديو شرح استخدامها."
    },
    {
      q: "ماذا لو حصلت مشكلة فنية أو توقف بعد التسليم؟",
      a: "نحن نضمن جودة أكوادنا. نقدم ضماناً ودعماً فنياً مجانياً يتراوح بين شهر إلى سنة (حسب الباقة المختارة) لمعالجة أي خلل أو عطل برمجي دون أي تكلفة إضافية."
    }
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="py-24 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-16 text-center"
      >
        <div className="w-20 h-20 bg-brand-bg-secondary rounded-2xl flex items-center justify-center mx-auto mb-6 border border-brand-border shadow-sm">
          <HelpCircle size={36} className="text-brand-text-primary" />
        </div>
        <h1 className="text-4xl font-black text-brand-text-primary mb-4 tracking-tight">الأسئلة الشائعة</h1>
        <p className="text-brand-text-secondary font-medium">أكثر ما يسألنا عنه عملاؤنا حول خدمات التطوير والبرمجة.</p>
      </motion.div>

      <div className="space-y-4">
        {faqs.map((faq, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`border rounded-2xl overflow-hidden transition-all duration-300 ${openIndex === idx ? 'bg-brand-bg-secondary border-brand-blue/30 shadow-md' : 'bg-brand-bg-primary border-brand-border'}`}
          >
            <button
              onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
              className="w-full text-right px-6 py-5 focus:outline-none flex justify-between items-center"
            >
              <h3 className="font-bold text-brand-text-primary text-lg ml-8">{faq.q}</h3>
              <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-transform duration-300 ${openIndex === idx ? 'bg-brand-blue/10 text-brand-blue rotate-180' : 'bg-brand-bg-secondary text-brand-text-secondary border border-brand-border'}`}>
                <ChevronDown size={18} />
              </div>
            </button>
            <AnimatePresence>
              {openIndex === idx && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="px-6 pb-6 pt-2 border-t border-brand-border/50 text-brand-text-secondary leading-relaxed font-medium">
                    {faq.a}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
