import { motion } from "motion/react";
import { ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";

export default function Portfolio() {
  const projects = [
    {
      title: "تطبيق Codiar AI",
      category: "تطبيق ذكاء اصطناعي",
      desc: "منصة متطورة لتوليد المحتوى وتحليل البيانات باستخدام نماذج الذكاء الاصطناعي المتقدمة.",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=800",
      link: "#"
    },
    {
      title: "منصة إنجاز العقارية",
      category: "منصة تجارية",
      desc: "نظام شامل لإدارة العقارات والأملاك مع لوحة تحكم إدارية متكاملة للوكلاء العقاريين والعملاء.",
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=800",
      link: "#"
    },
    {
      title: "منيو مطعم لذائذ",
      category: "منيو إلكتروني ذكي",
      desc: "قائمة طعام إلكترونية تفاعلية تدعم مسح الـ QR للطلبات المباشرة داخل المطعم وخارجه.",
      image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=800",
      link: "#"
    },
    {
      title: "دعوة زفاف البارون",
      category: "دعوات إلكترونية",
      desc: "بطاقة دعوة إلكترونية فاخرة متحركة، مع نظام تأكيد حضور مخصص وإدارة أعداد الضيوف.",
      image: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=800",
      link: "#"
    }
  ];

  return (
    <div className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-20"
      >
        <h1 className="text-4xl md:text-5xl font-black text-brand-text-primary mb-6">معرض أعمالنا</h1>
        <p className="text-xl text-brand-text-secondary max-w-2xl mx-auto font-medium leading-relaxed">
          نفخر بتقديم حلول برمجية متميزة لمختلف القطاعات. تصفح أبرز المشاريع التي قمنا بإنجازها لعملائنا في العراق وخارجه.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {projects.map((project, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.1 }}
            className="group rounded-3xl overflow-hidden bg-brand-bg-secondary border border-brand-border shadow-sm hover:shadow-xl transition-all duration-500"
          >
            <div className="relative h-72 overflow-hidden bg-brand-bg-primary">
              <img 
                src={project.image} 
                alt={project.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-8">
                <Link to={project.link} className="flex items-center gap-2 text-white font-bold bg-white/20 hover:bg-white/30 backdrop-blur-md px-6 py-3 rounded-xl transition-colors">
                  زيارة المشروع
                  <ExternalLink size={18} />
                </Link>
              </div>
            </div>
            <div className="p-8">
              <span className="text-sm font-bold text-brand-orange bg-brand-orange/10 px-3 py-1 rounded-full mb-4 inline-block">{project.category}</span>
              <h3 className="text-2xl font-bold text-brand-text-primary mb-3">{project.title}</h3>
              <p className="text-brand-text-secondary font-medium leading-relaxed">{project.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-24 text-center">
        <h3 className="text-2xl font-bold text-brand-text-primary mb-6">هل أعجبتك أعمالنا؟</h3>
        <Link to="/order">
          <button className="px-10 py-4 bg-brand-text-primary text-brand-bg-primary hover:bg-brand-text-secondary rounded-xl font-bold transition-colors shadow-lg">
            ابدأ مشروعك المشابه الآن
          </button>
        </Link>
      </div>
    </div>
  )
}
