import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { Check } from "lucide-react";

export default function Packages() {
  const packages = [
    {
      name: "الباقة الأساسية",
      desc: "مناسبة للأعمال الناشئة والمشاريع الصغرى",
      price: "150,000",
      features: [
        "صفحة هبوط احترافية واحدة",
        "استضافة مجانية لمدة سنة",
        "دعم فني لمدة شهر",
        "تكامل مع وسائل التواصل",
        "متوافق مع الهواتف الذكية"
      ],
      color: "bg-brand-bg-secondary",
      borderColor: "border-brand-border",
      buttonColor: "bg-brand-text-primary text-brand-bg-primary hover:bg-brand-text-secondary"
    },
    {
      name: "الباقة الذهبية",
      desc: "مثالية للشركات والمطاعم والمتاجر",
      price: "350,000",
      featured: true,
      features: [
        "موقع متعدد الصفحات (حتى 5 صفحات)",
        "لوحة تحكم إدارية مبسطة",
        "استضافة ونطاق مجاني لسنة",
        "دعم فني لمدة 3 أشهر",
        "تصميم الهوية البصرية الأساسية",
        "إحصائيات متقدمة للزوار",
        "متوافق ومحسن لمحركات البحث (SEO)"
      ],
      color: "bg-brand-text-primary text-brand-bg-primary relative overflow-hidden",
      borderColor: "border-brand-text-primary",
      buttonColor: "bg-brand-orange text-white hover:bg-orange-600 border-none shadow-lg shadow-brand-orange/20"
    },
    {
      name: "باقة بريميوم VIP",
      desc: "للأنظمة المعقدة والمنصات التفاعلية",
      price: "مخصص",
      features: [
        "منصة كاملة الميزات حسب الطلب",
        "لوحة تحكم احترافية كاملة الصلاحيات",
        "أنظمة قواعد البيانات السحابية",
        "تكامل مع بوابات الدفع الإلكتروني",
        "استضافة سحابية عالية الأداء",
        "دعم فني وبرمجي متواصل (سنة)",
        "تحسين شامل لمحركات البحث والأداء"
      ],
      color: "bg-brand-bg-secondary",
      borderColor: "border-brand-border",
      buttonColor: "bg-brand-text-primary text-brand-bg-primary hover:bg-brand-text-secondary"
    }
  ];

  return (
    <div className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-20"
      >
        <span className="text-brand-blue font-bold tracking-widest text-sm uppercase mb-4 block">أسعار تنافسية</span>
        <h1 className="text-4xl md:text-5xl font-black text-brand-text-primary mb-6">الباقات والأسعار</h1>
        <p className="text-xl text-brand-text-secondary max-w-2xl mx-auto font-medium leading-relaxed">
          اختر الباقة المناسبة لاحتياجات عملك وميزانيتك. جميع باقاتنا صُممت لتقديم أفضل قيمة مقابل استثمارك الرقمي.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {packages.map((pkg, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`border rounded-3xl p-8 flex flex-col ${pkg.color} ${pkg.borderColor} ${pkg.featured ? 'transform md:-translate-y-4 shadow-2xl' : 'shadow-sm'}`}
          >
            {pkg.featured && (
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-orange/10 rounded-full blur-2xl pointer-events-none"></div>
            )}
            {pkg.featured && (
              <span className="bg-brand-orange text-white text-xs font-bold px-3 py-1 rounded-full w-fit mb-4">الأكثر طلباً</span>
            )}
            
            <h3 className={`text-2xl font-bold mb-2 ${pkg.featured ? 'text-brand-bg-primary' : 'text-brand-text-primary'}`}>{pkg.name}</h3>
            <p className={`text-sm mb-6 ${pkg.featured ? 'text-brand-bg-primary/80' : 'text-brand-text-secondary'}`}>{pkg.desc}</p>
            
            <div className={`mb-8 pb-8 border-b ${pkg.featured ? 'border-brand-bg-primary/20' : 'border-brand-border'}`}>
              <div className="flex items-baseline gap-2">
                <span className={`text-5xl font-black tracking-tight ${pkg.featured ? 'text-brand-bg-primary' : 'text-brand-text-primary'}`}>
                  {pkg.price}
                </span>
                {pkg.price !== "مخصص" && <span className={`font-bold ${pkg.featured ? 'text-brand-bg-primary/80' : 'text-brand-text-primary'}`}>د.ع</span>}
              </div>
            </div>

            <ul className="space-y-4 flex-1 mb-8">
              {pkg.features.map((feat, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className={`mt-0.5 rounded-full p-1 flex-shrink-0 ${pkg.featured ? 'bg-brand-orange text-white' : 'bg-brand-bg-primary text-brand-text-primary border border-brand-border'}`}>
                    <Check size={14} className="stroke-[3]" />
                  </span>
                  <span className={`font-medium ${pkg.featured ? 'text-brand-bg-primary' : 'text-brand-text-secondary'}`}>{feat}</span>
                </li>
              ))}
            </ul>

            <Link to="/order" className="mt-auto">
              <button className={`w-full py-4 rounded-xl font-bold transition-all ${pkg.buttonColor}`}>
                اختيار الباقة
              </button>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
