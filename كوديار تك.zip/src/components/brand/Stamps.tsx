import React from "react";

interface StatusStampProps {
  status: "unpaid" | "pending" | "paid" | "development" | "completed" | "cancelled" | "suspended" | string;
  date?: string;
  className?: string;
}

export function StatusStamp({ status, date, className = "" }: StatusStampProps) {
  const configs = {
    unpaid: { text: "غير مدفوع", color: "text-red-500 border-red-500 bg-red-500/5", subtext: "UNPAID BILL" },
    pending: { text: "قيد المراجعة", color: "text-orange-500 border-orange-500 bg-orange-500/5", subtext: "PENDING REVIEW" },
    paid: { text: "مدفوع", color: "text-green-500 border-green-500 bg-green-500/5", subtext: "PAID IN FULL" },
    development: { text: "قيد التطوير", color: "text-blue-500 border-blue-500 bg-blue-500/5", subtext: "IN DEVELOPMENT" },
    completed: { text: "مكتمل", color: "text-emerald-500 border-emerald-500 bg-emerald-500/5", subtext: "COMPLETED" },
    cancelled: { text: "ملغي", color: "text-slate-500 border-slate-500 bg-slate-500/5", subtext: "CANCELLED" },
    suspended: { text: "معلق", color: "text-rose-600 border-rose-600 bg-rose-600/5", subtext: "SUSPENDED" }
  };

  const key = (status || "unpaid").toLowerCase();
  const config = configs[key as keyof typeof configs] || configs.unpaid;
  const stampDate = date || new Date().toLocaleDateString('en-GB');

  return (
    <div 
      className={`relative flex flex-col items-center justify-center p-4 border-4 border-double rounded-2xl w-36 h-36 font-black uppercase tracking-wider select-none transform rotate-[-6deg] hover:rotate-[-4deg] transition-transform duration-300 ${config.color} shadow-md shrink-0 ${className}`}
      style={{ fontFamily: '"Cairo", "Inter", sans-serif' }}
    >
      {/* Dashed outer accent */}
      <div className="absolute inset-1 border border-dotted border-current opacity-40 rounded-xl"></div>
      
      {/* Stamp text */}
      <span className="text-xl font-black text-center leading-none mt-1 tracking-tight select-none">
        {config.text}
      </span>
      
      {/* Separator and subtext */}
      <div className="w-full text-center border-t border-b border-current/20 my-2.5 py-0.5 text-[8px] font-mono tracking-[0.2em] opacity-85 select-none">
        {config.subtext}
      </div>
      
      {/* Bottom stamp date */}
      <span className="text-[8px] font-mono tracking-tight opacity-75">
        {stampDate}
      </span>
    </div>
  );
}

export function CodiarCompanyStamp({ className = "" }: { className?: string }) {
  const currentYear = new Date().getFullYear();
  return (
    <div 
      className={`relative flex items-center justify-center w-36 h-36 border-4 border-dashed border-[#3b82f6]/40 rounded-full select-none transform rotate-[6deg] hover:rotate-[8deg] transition-transform duration-300 opacity-90 shadow-sm shrink-0 ${className}`}
      style={{ fontFamily: '"Cairo", "Inter", sans-serif' }}
    >
      <div className="absolute inset-1 border border-double border-[#3b82f6]/30 rounded-full flex flex-col items-center justify-center bg-[#3b82f6]/2">
        <div className="text-[7px] font-bold text-[#3b82f6]/70 tracking-[0.16em] mb-1">CODIAR TECH</div>
        
        {/* Micro logo dynamic path */}
        <svg className="w-8 h-8 opacity-75 mb-0.5" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M50 15 L82 32 L82 68 L50 85 L18 68 L18 32 Z" stroke="#3b82f6" strokeWidth="6" strokeLinejoin="round" fill="none" />
          <path d="M42 40 L32 50 L42 60 M58 40 L68 50 L58 60" stroke="#3b82f6" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        
        <div className="text-[10px] font-black text-[#F97316] tracking-wide leading-none select-none">
          كوديار تك
        </div>
        <div className="text-[6px] font-mono text-slate-500 tracking-wider mt-1 select-none">
          OFFICIAL SEAL {currentYear}
        </div>
      </div>
    </div>
  );
}
