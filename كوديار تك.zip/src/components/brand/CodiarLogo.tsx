import React from "react";

interface CodiarLogoProps {
  className?: string;
  size?: number;
  light?: boolean;
}

export function CodiarLogo({ className = "", size = 40, light = false }: CodiarLogoProps) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <svg 
        width={size} 
        height={size} 
        viewBox="0 0 100 100" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        <defs>
          <linearGradient id="codiar-logo-g" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#F97316" />
          </linearGradient>
        </defs>
        {/* Shield Border */}
        <path 
          d="M50 8 L88 28 L88 68 L50 92 L12 68 L12 28 Z" 
          stroke="url(#codiar-logo-g)" 
          strokeWidth="8" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
          fill="#0B0F19" 
        />
        {/* Bracket Left */}
        <path 
          d="M40 36 L26 50 L40 64" 
          stroke="#3b82f6" 
          strokeWidth="7" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
        />
        {/* Bracket Right */}
        <path 
          d="M60 36 L74 50 L60 64" 
          stroke="#F97316" 
          strokeWidth="7" 
          strokeLinecap="round" 
          strokeLinejoin="round" 
        />
        {/* Slash Center */}
        <path 
          d="M47 32 L53 68" 
          stroke="url(#codiar-logo-g)" 
          strokeWidth="6" 
          strokeLinecap="round" 
        />
      </svg>
      <span className={`text-2xl font-black font-sans tracking-tight leading-none ${light ? "text-slate-100" : "text-brand-text-primary mb-0.5"}`}>
        كوديار <span className="text-brand-orange">تك</span>
      </span>
    </div>
  );
}
