import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { useTheme } from "../../contexts/ThemeContext";
import { Button } from "../ui/Button";
import { signInWithGoogle, logOut } from "../../lib/firebase";
import { Moon, Sun, User as UserIcon, Settings, LogOut, Grid } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { CodiarLogo } from "../brand/CodiarLogo";

export function Navbar() {
  const { user, dbUser } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  const isClientDashboard = location.pathname.startsWith('/dashboard');
  const isAdminDashboard = location.pathname.startsWith('/admin');
  const isDashboard = isClientDashboard || isAdminDashboard;

  const links = [
    { name: "الرئيسية", path: "/" },
    { name: "الخدمات", path: "/services" },
    { name: "الباقات", path: "/packages" },
    { name: "أعمالنا", path: "/portfolio" },
    { name: "الأسئلة الشائعة", path: "/faq" },
  ];

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <nav className="sticky top-0 z-50 w-full glass-panel border-b-brand-border/50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-3 group">
              <CodiarLogo className="transition-transform group-hover:scale-105" />
            </Link>

            {!isDashboard && (
              <div className="hidden md:flex items-center gap-6 mr-10">
                {links.map((link) => (
                  <Link
                    key={link.name}
                    to={link.path}
                    className="text-brand-text-secondary hover:text-brand-blue font-medium text-sm transition-colors"
                  >
                    {link.name}
                  </Link>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full border border-brand-border bg-brand-bg-secondary hover:bg-brand-bg-primary text-brand-text-secondary hover:text-brand-text-primary transition-all relative overflow-hidden group focus:outline-none"
              aria-label="Toggle Theme"
            >
              <div className="relative w-5 h-5 flex items-center justify-center">
                <AnimatePresence mode="wait">
                  {theme === 'dark' ? (
                    <motion.div
                      key="moon"
                      initial={{ opacity: 0, rotate: -90, scale: 0.5 }}
                      animate={{ opacity: 1, rotate: 0, scale: 1 }}
                      exit={{ opacity: 0, rotate: 90, scale: 0.5 }}
                      transition={{ duration: 0.3 }}
                      className="absolute"
                    >
                      <Moon size={18} />
                    </motion.div>
                  ) : (
                    <motion.div
                      key="sun"
                      initial={{ opacity: 0, rotate: 90, scale: 0.5 }}
                      animate={{ opacity: 1, rotate: 0, scale: 1 }}
                      exit={{ opacity: 0, rotate: -90, scale: 0.5 }}
                      transition={{ duration: 0.3 }}
                      className="absolute text-brand-orange"
                    >
                      <Sun size={18} />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </button>

            {user ? (
              <div className="relative" ref={profileRef}>
                <button 
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  className="flex items-center gap-3 p-1 rounded-full border border-brand-border bg-brand-bg-secondary hover:border-brand-blue/50 transition-all focus:outline-none"
                >
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="Avatar" className="w-9 h-9 rounded-full object-cover" />
                  ) : (
                    <div className="w-9 h-9 rounded-full bg-brand-blue/10 text-brand-blue flex items-center justify-center">
                      <UserIcon size={18} />
                    </div>
                  )}
                  <span className="text-sm font-semibold text-brand-text-primary hidden sm:block pl-3">{dbUser?.name?.split(' ')[0]}</span>
                </button>

                <AnimatePresence>
                  {isProfileOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      transition={{ duration: 0.15 }}
                      className="absolute left-0 mt-2 w-64 rounded-2xl bg-brand-bg-secondary border border-brand-border shadow-xl overflow-hidden"
                    >
                      <div className="p-4 border-b border-brand-border flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-brand-blue/10 text-brand-blue flex items-center justify-center shrink-0">
                          {user.photoURL ? <img src={user.photoURL} alt="Avatar" className="w-10 h-10 rounded-full" /> : <UserIcon size={20} />}
                        </div>
                        <div className="overflow-hidden">
                          <p className="text-sm font-bold text-brand-text-primary truncate">{dbUser?.name}</p>
                          <p className="text-xs text-brand-text-secondary truncate">{user.email}</p>
                        </div>
                      </div>
                      <div className="p-2 flex flex-col gap-1 text-sm font-medium">
                        <Link 
                           to={dbUser?.role === 'admin' ? '/admin' : '/dashboard'} 
                           onClick={() => setIsProfileOpen(false)}
                           className="flex items-center gap-3 px-3 py-2 text-brand-text-primary hover:bg-brand-bg-primary rounded-lg transition-colors"
                        >
                          <Grid size={16} /> لوحة التحكم
                        </Link>

                        <button 
                          onClick={() => { logOut(); setIsProfileOpen(false); }}
                          className="flex items-center w-full gap-3 px-3 py-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors text-right mt-1"
                        >
                          <LogOut size={16} /> تسجيل الخروج
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <>
                <Button variant="ghost" className="hidden sm:inline-flex text-brand-text-primary hover:bg-brand-bg-secondary" onClick={signInWithGoogle}>تسجيل الدخول</Button>
                <Link to="/order">
                  <Button variant="primary" className="bg-brand-text-primary text-brand-bg-primary hover:bg-brand-text-secondary transition-colors">اطلب مشروعك</Button>
                </Link>
              </>
            )}
          </div>
          
        </div>
      </div>
    </nav>
  );
}
