import { Link } from "react-router-dom";
import { CodiarLogo } from "../brand/CodiarLogo";

export function Footer() {
  return (
    <footer className="bg-brand-navy pt-16 pb-8 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          
          <div className="col-span-1 md:col-span-2">
             <Link to="/" className="flex items-center gap-2 mb-6 group">
              <CodiarLogo light className="transition-transform group-hover:scale-105" />
            </Link>
            <p className="text-brand-gray-100/70 max-w-sm text-sm leading-relaxed font-medium">
              نحن نقدم حلول برمجية متكاملة للشركات الناشئة والمطاعم والعيادات في العراق.
              نصنع تجارب رقمية فاخرة تعكس قيمة علامتك التجارية.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg">روابط سريعة</h4>
            <ul className="space-y-4 text-sm font-medium">
              <li><Link to="/about" className="text-brand-gray-100/70 hover:text-white transition-colors">من نحن</Link></li>
              <li><Link to="/services" className="text-brand-gray-100/70 hover:text-white transition-colors">الخدمات</Link></li>
              <li><Link to="/packages" className="text-brand-gray-100/70 hover:text-white transition-colors">الباقات</Link></li>
              <li><Link to="/portfolio" className="text-brand-gray-100/70 hover:text-white transition-colors">أعمالنا</Link></li>
              <li><Link to="/contact" className="text-brand-gray-100/70 hover:text-white transition-colors">تواصل معنا</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg">القانونية</h4>
            <ul className="space-y-4 text-sm font-medium">
              <li><Link to="/privacy" className="text-brand-gray-100/70 hover:text-white transition-colors">سياسة الخصوصية</Link></li>
              <li><Link to="/terms" className="text-brand-gray-100/70 hover:text-white transition-colors">شروط الخدمة</Link></li>
              <li><Link to="/faq" className="text-brand-gray-100/70 hover:text-white transition-colors">الأسئلة الشائعة</Link></li>
            </ul>
          </div>

        </div>
        
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-brand-gray-100/50 text-sm font-medium">
            جميع الحقوق محفوظة &copy; {new Date().getFullYear()} كوديار تك - حلول برمجية متطورة.
          </p>
          <div className="flex gap-4">
            {/* Social Icons would go here */}
          </div>
        </div>
      </div>
    </footer>
  );
}
