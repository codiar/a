export type Role = "client" | "admin";

export interface User {
  uid: string;
  name: string;
  email: string;
  phone?: string;
  role: Role;
  createdAt: number;
  updatedAt: number;
}

export type ProjectStatus = "pending" | "development" | "active" | "suspended" | "cancelled" | "archived";

export interface Project {
  id: string;
  clientId: string;
  name: string;
  type: string;
  status: ProjectStatus;
  statusList?: string[];
  package: string;
  url?: string;
  activationDate?: number;
  expirationDate?: number;
  productsCount?: number;
  createdAt: number;
  updatedAt: number;
  orderId?: string;
  receiptId?: string;
  featuresRequest?: string;
  requestedUpgrade?: string;
  requestedDuration?: string;
}

export type OrderStatus = "pending" | "unpaid" | "paid" | "completed" | "cancelled";

export interface Order {
  id: string; // The ORD-xxxx ID
  clientId: string;
  customerName: string;
  phone: string;
  projectName: string;
  category: string;
  package: string;
  duration: string;
  paymentMethod: string;
  status: OrderStatus;
  statusList?: string[];
  description?: string;
  proofLink?: string;
  adminNotes?: string;
  total: number;
  createdAt: number;
  updatedAt: number;
  projectId?: string;
  receiptId?: string;
}

export interface Receipt {
  id: string;
  orderId: string;
  clientId: string;
  status: OrderStatus;
  statusList?: string[];
  total: number;
  createdAt: number;
  projectId?: string;
}

export type ReviewStatus = "pending" | "approved" | "rejected";

export interface Review {
  id: string;
  clientId: string;
  clientName: string;
  stars: number;
  comment: string;
  status: ReviewStatus;
  createdAt: number;
}
