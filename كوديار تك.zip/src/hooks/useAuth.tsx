import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { User as FirebaseUser } from "firebase/auth";
import { doc, getDoc, setDoc, onSnapshot } from "firebase/firestore";
import { auth, db } from "../lib/firebase";
import type { User } from "../types";

interface AuthContextType {
  user: FirebaseUser | null;
  dbUser: User | null;
  loading: boolean;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  dbUser: null,
  loading: true,
  isAdmin: false,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [dbUser, setDbUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubsribeDb: (() => void) | undefined;

    const unsubscribe = auth.onAuthStateChanged(async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        // Fetch or create user document
        const userRef = doc(db, "users", firebaseUser.uid);
        const userSnap = await getDoc(userRef);
        
        if (!userSnap.exists()) {
          const isUserAdmin = firebaseUser.email === 'codiartech@gmail.com';
          const newUser: User = {
            uid: firebaseUser.uid,
            name: firebaseUser.displayName || "Unknown",
            email: firebaseUser.email || "",
            role: isUserAdmin ? "admin" : "client",
            createdAt: Date.now(),
            updatedAt: Date.now(),
          };
          await setDoc(userRef, newUser);
          setDbUser(newUser);
        } else {
          setDbUser(userSnap.data() as User);
        }
        
        // Listen to DB User changes
        if (unsubsribeDb) unsubsribeDb();
        unsubsribeDb = onSnapshot(userRef, (docSnap) => {
            if (docSnap.exists()){
                setDbUser(docSnap.data() as User);
            }
        });

        setLoading(false);
      } else {
        if (unsubsribeDb) unsubsribeDb();
        setDbUser(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribe();
      if (unsubsribeDb) unsubsribeDb();
    };
  }, []);

  return (
    <AuthContext.Provider value={{ user, dbUser, loading, isAdmin: user?.email === "codiartech@gmail.com" }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
